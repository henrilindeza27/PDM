package pt.ubi.di.pdm.cardfolio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import pt.ubi.di.pdm.cardfolio.data.DemoSeed
import pt.ubi.di.pdm.cardfolio.data.fromCents
import pt.ubi.di.pdm.cardfolio.data.toCents
import pt.ubi.di.pdm.cardfolio.util.PasswordHasher

class DataLayerTest {

    @Test
    fun passwordHasher_verifiesOnlyTheRightPassword() {
        val stored = PasswordHasher.hash("password123")
        assertTrue(PasswordHasher.verify("password123", stored))
        assertFalse(PasswordHasher.verify("password124", stored))
        assertFalse(PasswordHasher.verify("password123", "not-a-hash"))
    }

    @Test
    fun demoSeedHash_matchesDemoPassword() {
        assertTrue(PasswordHasher.verify("password123", DemoSeed.DEMO_PASSWORD_HASH))
    }

    @Test
    fun passwordHasher_usesRandomSalt() {
        assertNotEquals(PasswordHasher.hash("same"), PasswordHasher.hash("same"))
    }

    @Test
    fun cents_roundTripWithoutFloatingPointDrift() {
        assertEquals(8550L, 85.5.toCents())
        assertEquals(30L, (0.1 + 0.2).toCents()) // 0.30000000000000004 in floating point
        assertEquals(85.5, 8550L.fromCents(), 0.0)
    }
}
