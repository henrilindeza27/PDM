package pt.ubi.di.pdm.cardfolio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.model.SalesPeriod
import pt.ubi.di.pdm.cardfolio.model.SortMode
import pt.ubi.di.pdm.cardfolio.model.StatusFilter
import pt.ubi.di.pdm.cardfolio.ui.screens.niceAxis
import pt.ubi.di.pdm.cardfolio.util.CardStats
import pt.ubi.di.pdm.cardfolio.util.CardStats.totalCost
import pt.ubi.di.pdm.cardfolio.util.CardStats.realizedProfit
import pt.ubi.di.pdm.cardfolio.util.FormatUtils
import java.time.LocalDate

class CardStatsTest {

    private val today = LocalDate.of(2026, 10, 22) // Thursday

    private fun card(
        id: String,
        cost: Double = 10.0,
        value: Double = 20.0,
        purpose: CardPurpose = CardPurpose.PERSONAL,
        status: CardStatus = CardStatus.KEPT,
        salePrice: Double? = null,
        saleDate: String? = null,
        playerId: String? = null,
        date: String = "2026-01-01",
        name: String = "Carta $id",
        additionalCost: Double = 0.0
    ) = CardItem(
        id = id, name = name, categoryId = "cat_1", category = "Futebol", edition = "Ed", date = date, cost = cost, value = value,
        purpose = purpose, status = status, salePrice = salePrice, saleDate = saleDate, playerId = playerId,
        additionalCost = additionalCost
    )

    // Same sales as the demo seed (CardDatabase), dated relative to [today]
    private val seedSales = listOf(
        card("haaland", cost = 60.0, additionalCost = 5.0, salePrice = 110.0, saleDate = "2026-10-22", status = CardStatus.SOLD),
        card("mewtwo", cost = 90.0, salePrice = 150.0, saleDate = "2026-10-19", status = CardStatus.SOLD),
        card("bellingham", cost = 40.0, additionalCost = 4.0, salePrice = 38.0, saleDate = "2026-10-02", status = CardStatus.SOLD),
        card("blastoise", cost = 120.0, additionalCost = 6.0, salePrice = 210.0, saleDate = "2026-06-24", status = CardStatus.SOLD),
        card("yamal", cost = 25.0, additionalCost = 3.0, salePrice = 70.0, saleDate = "2025-09-17", status = CardStatus.SOLD)
    )

    @Test
    fun seedSales_revenueMinusCostEqualsSumOfProfitsInEveryPeriod() {
        // period -> (count, revenue, cost, profit) worked out by hand
        val expected = mapOf(
            SalesPeriod.DAY to listOf(1.0, 110.0, 65.0, 45.0),
            SalesPeriod.WEEK to listOf(2.0, 260.0, 155.0, 105.0),
            SalesPeriod.MONTH to listOf(3.0, 298.0, 199.0, 99.0),
            SalesPeriod.YEAR to listOf(4.0, 508.0, 325.0, 183.0),
            SalesPeriod.ALL to listOf(5.0, 578.0, 353.0, 225.0)
        )
        expected.forEach { (period, values) ->
            val sold = CardStats.soldInPeriod(seedSales, period, today)
            val revenue = sold.sumOf { it.salePrice!! }
            val cost = sold.sumOf { it.totalCost }
            val profit = sold.sumOf { it.realizedProfit }
            assertEquals(period.name, listOf(sold.size.toDouble(), revenue, cost, profit), values)
            assertEquals(period.name, revenue - cost, profit, 0.001)
        }
        // Monthly profits add up to the same total shown everywhere else
        val activity = CardStats.monthlyActivity(seedSales, today)
        assertEquals(225.0, activity.sumOf { it.profit }, 0.001)
        assertEquals(5, activity.sumOf { it.sold })
        val byMonth = activity.filter { it.sold > 0 }.associate { it.month.toString() to it.profit }
        assertEquals(mapOf("2025-09" to 42.0, "2026-06" to 84.0, "2026-10" to 99.0), byMonth)
    }

    @Test
    fun soldInPeriod_filtersBySaleDate() {
        val cards = listOf(
            card("today", status = CardStatus.SOLD, saleDate = "2026-10-22"),
            card("monday", status = CardStatus.SOLD, saleDate = "2026-10-19"),
            card("lastWeek", status = CardStatus.SOLD, saleDate = "2026-10-15"),
            card("lastYear", status = CardStatus.SOLD, saleDate = "2025-10-22"),
            card("notSold", saleDate = "2026-10-22")
        )
        fun ids(period: SalesPeriod) = CardStats.soldInPeriod(cards, period, today).map { it.id }

        assertEquals(listOf("today"), ids(SalesPeriod.DAY))
        assertEquals(listOf("today", "monday"), ids(SalesPeriod.WEEK))
        assertEquals(listOf("today", "monday", "lastWeek"), ids(SalesPeriod.MONTH))
        assertEquals(listOf("today", "monday", "lastWeek", "lastYear"), ids(SalesPeriod.ALL))
    }

    @Test
    fun ranking_groupsAndSortsByCount() {
        val cards = listOf(
            card("1", cost = 5.0, playerId = "cr7"),
            card("2", cost = 7.0, playerId = "cr7"),
            card("3", cost = 3.0, playerId = "messi"),
            card("4")
        )
        val ranking = CardStats.ranking(cards, key = { it.playerId }) { it.uppercase() }

        assertEquals(2, ranking.size)
        assertEquals("CR7", ranking[0].label)
        assertEquals(2, ranking[0].count)
        assertEquals(12.0, ranking[0].invested, 0.001)
    }

    @Test
    fun monthlyActivity_coversEveryMonthWithPurchasesAndSales() {
        val cards = listOf(
            card("1", cost = 10.0, date = "2026-08-10", status = CardStatus.SOLD, salePrice = 30.0, saleDate = "2026-09-03"),
            card("2", cost = 10.0, date = "2026-08-15", status = CardStatus.SOLD, salePrice = 5.0, saleDate = "2026-10-01")
        )
        val activity = CardStats.monthlyActivity(cards, today)

        assertEquals(listOf("2026-08", "2026-09", "2026-10"), activity.map { it.month.toString() })
        assertEquals(2, activity[0].bought)
        assertEquals(20.0, activity[0].spent, 0.001)
        assertEquals(20.0, activity[1].profit, 0.001)
        assertEquals(-5.0, activity[2].profit, 0.001)
    }

    @Test
    fun personalGrowth_accumulatesInvestedAndValueMonthByMonth() {
        val cards = listOf(
            card("a", cost = 100.0, value = 150.0, date = "2026-08-05", additionalCost = 10.0),
            card("b", cost = 50.0, value = 40.0, date = "2026-10-01"),
            card("resale", cost = 999.0, purpose = CardPurpose.RESALE, date = "2026-09-01")
        )
        val growth = CardStats.personalGrowth(cards, today)

        // starts at zero the month before the first purchase, ends today
        assertEquals(listOf("2026-07", "2026-08", "2026-09", "2026-10"), growth.map { it.month.toString() })
        assertEquals(0.0, growth.first().invested, 0.0)
        assertEquals(110.0, growth[2].invested, 0.001)
        assertEquals(160.0, growth.last().invested, 0.001)
        assertEquals(190.0, growth.last().value, 0.001)
    }

    @Test
    fun toCsv_escapesQuotes() {
        val csv = CardStats.toCsv(listOf(card("1", name = "Ronaldo \"CR7\"")))
        assertTrue(csv.lines()[1].startsWith("\"1\",\"Ronaldo \"\"CR7\"\"\""))
    }

    @Test
    fun statusFilter_matchesPurposeAndStatus() {
        val stock = card("1", purpose = CardPurpose.RESALE)
        assertTrue(StatusFilter.NOT_LISTED.matches(stock))
        assertFalse(StatusFilter.IN_COLLECTION.matches(stock))
        assertTrue(StatusFilter.ALL.matches(stock))
    }

    @Test
    fun sortMode_highestValueUsesSalePriceForSoldCards() {
        val sorted = SortMode.HIGHEST_VALUE.sort(
            listOf(card("kept", value = 50.0), card("sold", value = 10.0, status = CardStatus.SOLD, salePrice = 80.0))
        )
        assertEquals(listOf("sold", "kept"), sorted.map { it.id })
    }

    @Test
    fun portugueseFormats_useCommaDecimals() {
        assertEquals("35,5%", FormatUtils.formatPercent(35.5))
        assertEquals("+63,7%", FormatUtils.formatPercent(63.74, includePlusSign = true))
        assertEquals("out 2026", FormatUtils.formatMonth("2026-10"))
        assertEquals("22 out 2026", FormatUtils.formatDateShort("2026-10-22"))
    }

    @Test
    fun niceAxis_usesRoundSteps() {
        assertEquals(listOf(0.0, 100.0, 200.0, 300.0, 400.0, 500.0), niceAxis(420.0))
        assertEquals(listOf(0.0, 20.0, 40.0, 60.0), niceAxis(55.0))
        assertEquals(listOf(0.0, 1.0, 2.0), niceAxis(1.0)) // never ends exactly on the top value
    }

    @Test
    fun parseDecimal_acceptsCommaAndDot() {
        assertEquals(85.5, FormatUtils.parseDecimal("85,50")!!, 0.001)
        assertEquals(85.5, FormatUtils.parseDecimal(" 85.50 ")!!, 0.001)
        assertNull(FormatUtils.parseDecimal("abc"))
    }
}
