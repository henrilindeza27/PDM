package pt.ubi.di.pdm.cardfolio.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import pt.ubi.di.pdm.cardfolio.model.CategoryType

// Every catalog row belongs to a user (deleted with the account) and, except categories,
// references a category by id (NO_ACTION: a category in use cannot be deleted).

@Entity(
    tableName = "categories",
    foreignKeys = [ForeignKey(entity = UserEntity::class, parentColumns = ["id"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("userId")]
)
data class CategoryEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val name: String,
    val type: CategoryType = CategoryType.OTHER,
    val isArchived: Boolean = false
)

@Entity(
    tableName = "collections",
    foreignKeys = [
        ForeignKey(entity = UserEntity::class, parentColumns = ["id"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"])
    ],
    indices = [Index("userId"), Index("categoryId")]
)
data class CollectionEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val categoryId: String,
    val name: String,
    val season: String,
    val manufacturer: String? = null,
    val isArchived: Boolean = false
)

@Entity(
    tableName = "players",
    foreignKeys = [
        ForeignKey(entity = UserEntity::class, parentColumns = ["id"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"])
    ],
    indices = [Index("userId"), Index("categoryId")]
)
data class PlayerEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val categoryId: String,
    val name: String,
    val country: String? = null,
    val isArchived: Boolean = false
)

@Entity(
    tableName = "clubs",
    foreignKeys = [
        ForeignKey(entity = UserEntity::class, parentColumns = ["id"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"])
    ],
    indices = [Index("userId"), Index("categoryId")]
)
data class ClubEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val categoryId: String,
    val name: String,
    val country: String? = null,
    val isArchived: Boolean = false
)

// Query results: catalog rows together with the name of their category (JOIN)

data class CollectionWithCategory(
    @Embedded val collection: CollectionEntity,
    val categoryName: String
)

data class PlayerWithCategory(
    @Embedded val player: PlayerEntity,
    val categoryName: String
)

data class ClubWithCategory(
    @Embedded val club: ClubEntity,
    val categoryName: String
)
