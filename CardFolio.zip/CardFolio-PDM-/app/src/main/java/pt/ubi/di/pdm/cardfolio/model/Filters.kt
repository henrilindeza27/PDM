package pt.ubi.di.pdm.cardfolio.model

import java.time.DayOfWeek
import java.time.LocalDate

/** Category filter value meaning "no category filter". */
const val ALL_CATEGORIES = "Todas"

enum class SortMode(val label: String) {
    RECENT("Mais recentes"),
    HIGHEST_VALUE("Maior valor"),
    NAME("Nome A-Z");

    fun sort(cards: List<CardItem>): List<CardItem> = when (this) {
        RECENT -> cards.sortedByDescending { it.date }
        HIGHEST_VALUE -> cards.sortedByDescending { if (it.status == CardStatus.SOLD) it.salePrice ?: it.value else it.value }
        NAME -> cards.sortedBy { it.name }
    }
}

enum class StatusFilter(val label: String) {
    ALL("Todos"),
    IN_COLLECTION("Na coleção"),
    NOT_LISTED("Por anunciar"), // resale card not listed yet; "stock" in the UI means every unsold resale card
    LISTED("À venda"),
    SOLD("Vendidas");

    fun matches(card: CardItem): Boolean = when (this) {
        ALL -> true
        IN_COLLECTION -> card.status == CardStatus.KEPT && card.purpose == CardPurpose.PERSONAL
        NOT_LISTED -> card.status == CardStatus.KEPT && card.purpose == CardPurpose.RESALE
        LISTED -> card.status == CardStatus.LISTED
        SOLD -> card.status == CardStatus.SOLD
    }
}

enum class StatsPurpose(val label: String) {
    PERSONAL("Coleção pessoal"),
    RESALE("Revenda"),
    ALL_OWNED("Todas em posse");

    fun matches(card: CardItem): Boolean = when (this) {
        PERSONAL -> card.purpose == CardPurpose.PERSONAL
        RESALE -> card.purpose == CardPurpose.RESALE
        ALL_OWNED -> true
    }
}

// Declaration order is the order of the chips in the finance tab
enum class SalesPeriod(val label: String) {
    ALL("Tudo"),
    DAY("Hoje"),
    WEEK("Esta semana"),
    MONTH("Este mês"),
    YEAR("Este ano");

    fun contains(date: LocalDate, today: LocalDate = LocalDate.now()): Boolean = when (this) {
        DAY -> date.isEqual(today)
        WEEK -> !date.isBefore(today.with(DayOfWeek.MONDAY)) && !date.isAfter(today)
        MONTH -> date.year == today.year && date.month == today.month
        YEAR -> date.year == today.year
        ALL -> true
    }
}
