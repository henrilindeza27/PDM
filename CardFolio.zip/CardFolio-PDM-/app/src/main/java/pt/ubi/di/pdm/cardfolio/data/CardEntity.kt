package pt.ubi.di.pdm.cardfolio.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus

/**
 * Money is stored in cents (Long) to avoid floating point rounding errors;
 * dates are ISO-8601 text ("YYYY-MM-DD"), which SQLite sorts correctly.
 * The edition text and category name are not stored: they come from the referenced rows.
 */
@Entity(
    tableName = "cards",
    foreignKeys = [
        ForeignKey(entity = UserEntity::class, parentColumns = ["id"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"]),
        ForeignKey(entity = CollectionEntity::class, parentColumns = ["id"], childColumns = ["collectionId"]),
        ForeignKey(entity = PlayerEntity::class, parentColumns = ["id"], childColumns = ["playerId"]),
        ForeignKey(entity = ClubEntity::class, parentColumns = ["id"], childColumns = ["clubId"])
    ],
    indices = [Index("userId"), Index("categoryId"), Index("collectionId"), Index("playerId"), Index("clubId")]
)
data class CardEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val categoryId: String,
    val collectionId: String? = null,
    val playerId: String? = null,
    val clubId: String? = null,
    val name: String,
    val date: String,
    val costCents: Long,
    val valueCents: Long,
    val additionalCostCents: Long = 0,
    val purpose: CardPurpose,
    val status: CardStatus,
    val imageUri: String? = null,
    val salePriceCents: Long? = null,
    val saleDate: String? = null,
    val cardNumber: String? = null,
    val variant: String? = null,
    val isAutograph: Boolean = false,
    val isPatch: Boolean = false,
    val isRookie: Boolean = false,
    val isNumbered: Boolean = false,
    val numberedCopy: Int? = null,
    val numberedTotal: Int? = null,
    val platform: String? = null,
    val notes: String? = null
)

/** A card row with the names of its category and collection (JOIN). */
data class CardWithNames(
    @Embedded val card: CardEntity,
    val categoryName: String,
    val collectionName: String?,
    val collectionSeason: String?
)
