package pt.ubi.di.pdm.cardfolio.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun DatePickerField(
    label: String,
    dateValue: String, // ISO "YYYY-MM-DD"
    onDateSelected: (String) -> Unit, // returns ISO "YYYY-MM-DD"
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val initialDate = try {
        LocalDate.parse(dateValue)
    } catch (e: Exception) {
        LocalDate.now()
    }

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val selected = LocalDate.of(year, month + 1, dayOfMonth)
            onDateSelected(selected.toString()) // "YYYY-MM-DD"
        },
        initialDate.year,
        initialDate.monthValue - 1,
        initialDate.dayOfMonth
    )

    val displayDate = try {
        val parsed = LocalDate.parse(dateValue)
        val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
        parsed.format(formatter)
    } catch (e: Exception) {
        dateValue
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clickable { datePickerDialog.show() }
    ) {
        OutlinedTextField(
            value = displayDate,
            onValueChange = {},
            readOnly = true,
            enabled = false, // ensures text field itself doesn't intercept touch, allowing Box clickable
            label = { Text(label) },
            trailingIcon = {
                IconButton(onClick = { datePickerDialog.show() }) {
                    Icon(imageVector = Icons.Outlined.CalendarToday, contentDescription = "Abrir calendário")
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
