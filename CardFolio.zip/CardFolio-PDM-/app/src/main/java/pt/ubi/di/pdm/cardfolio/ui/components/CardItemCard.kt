package pt.ubi.di.pdm.cardfolio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRed
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreen
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreenSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmberSoft
import pt.ubi.di.pdm.cardfolio.util.CardStats.realizedProfit
import pt.ubi.di.pdm.cardfolio.util.CardStats.totalCost
import pt.ubi.di.pdm.cardfolio.util.FormatUtils

@Composable
fun CardItemGridCard(
    card: CardItem,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onTogglePurposeClick: () -> Unit,
    onListCardClick: () -> Unit,
    onRegisterSaleClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        color = SurfaceWhite
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Card Image / Placeholder with Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.35f)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFFF3F4F6), Color(0xFFE5E7EB))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (!card.imageUri.isNullOrBlank()) {
                    AsyncImage(
                        model = card.imageUri,
                        contentDescription = card.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Style,
                            contentDescription = null,
                            tint = PrimaryIndigo.copy(alpha = 0.5f),
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = card.category,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }
                }

                // Purpose Badge on Top Left
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    CardPurposeBadge(purpose = card.purpose, status = card.status)
                }

                // Top Right Overflow Menu
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                ) {
                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier
                                .size(28.dp)
                                .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(14.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.MoreVert,
                                contentDescription = "Opções",
                                tint = TextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        CardMenuDropdown(
                            expanded = menuExpanded,
                            card = card,
                            onDismiss = { menuExpanded = false },
                            onDetailClick = {
                                menuExpanded = false
                                onClick()
                            },
                            onEditClick = {
                                menuExpanded = false
                                onEditClick()
                            },
                            onTogglePurposeClick = {
                                menuExpanded = false
                                onTogglePurposeClick()
                            },
                            onListCardClick = {
                                menuExpanded = false
                                onListCardClick()
                            },
                            onRegisterSaleClick = {
                                menuExpanded = false
                                onRegisterSaleClick()
                            },
                            onDeleteClick = {
                                menuExpanded = false
                                onDeleteClick()
                            }
                        )
                    }
                }
            }

            // Card Details Body
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                // Category tag
                Text(
                    text = card.category.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryIndigo,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TagBackground)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Name & Edition
                Text(
                    text = card.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = card.edition,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Financials section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Custo",
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                        Text(
                            text = FormatUtils.formatCurrency(card.totalCost),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        if (card.status == CardStatus.SOLD) {
                            val salePrice = card.salePrice ?: card.value
                            val profit = card.realizedProfit
                            Text(
                                text = "Venda (${FormatUtils.formatCurrency(profit, true)})",
                                fontSize = 10.sp,
                                color = if (profit < 0) LossRed else SuccessGreen
                            )
                            Text(
                                text = FormatUtils.formatCurrency(salePrice),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen
                            )
                        } else {
                            Text(
                                text = if (card.purpose == CardPurpose.PERSONAL) "Estimado" else "Preço",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                            Text(
                                text = FormatUtils.formatCurrency(card.value),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Card Footer (Date & Status)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = FormatUtils.formatDateShort(card.date),
                        fontSize = 10.sp,
                        color = TextMuted
                    )

                    CardStatusIndicator(status = card.status, purpose = card.purpose)
                }
            }
        }
    }
}

@Composable
fun CardItemListRow(
    card: CardItem,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onTogglePurposeClick: () -> Unit,
    onListCardClick: () -> Unit,
    onRegisterSaleClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = SurfaceWhite
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(TagBackground),
                contentAlignment = Alignment.Center
            ) {
                if (!card.imageUri.isNullOrBlank()) {
                    AsyncImage(
                        model = card.imageUri,
                        contentDescription = card.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Outlined.Style,
                        contentDescription = null,
                        tint = PrimaryIndigo,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Main Info
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = card.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    CardPurposeBadge(purpose = card.purpose, status = card.status, isCompact = true)
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${card.edition} · ${card.category}",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Custo: ${FormatUtils.formatCurrency(card.totalCost)}",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                    Text(
                        text = " • ",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                    Text(
                        text = FormatUtils.formatDateShort(card.date),
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Financial & Actions
            Column(horizontalAlignment = Alignment.End) {
                if (card.status == CardStatus.SOLD) {
                    val salePrice = card.salePrice ?: card.value
                    Text(
                        text = FormatUtils.formatCurrency(salePrice),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreen
                    )
                    Text(
                        text = "Vendida",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SuccessGreen
                    )
                } else {
                    Text(
                        text = FormatUtils.formatCurrency(card.value),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    CardStatusIndicator(status = card.status, purpose = card.purpose)
                }
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.MoreVert,
                        contentDescription = "Opções",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                CardMenuDropdown(
                    expanded = menuExpanded,
                    card = card,
                    onDismiss = { menuExpanded = false },
                    onDetailClick = {
                        menuExpanded = false
                        onClick()
                    },
                    onEditClick = {
                        menuExpanded = false
                        onEditClick()
                    },
                    onTogglePurposeClick = {
                        menuExpanded = false
                        onTogglePurposeClick()
                    },
                    onListCardClick = {
                        menuExpanded = false
                        onListCardClick()
                    },
                    onRegisterSaleClick = {
                        menuExpanded = false
                        onRegisterSaleClick()
                    },
                    onDeleteClick = {
                        menuExpanded = false
                        onDeleteClick()
                    }
                )
            }
        }
    }
}

@Composable
fun CardPurposeBadge(
    purpose: CardPurpose,
    status: CardStatus,
    isCompact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val (label, icon, bg, tint) = when {
        status == CardStatus.SOLD -> Quadruple(
            "Vendida",
            Icons.Outlined.CheckCircle,
            SuccessGreenSoft,
            SuccessGreen
        )
        purpose == CardPurpose.PERSONAL -> Quadruple(
            "Coleção Pessoal",
            Icons.Outlined.Favorite,
            PrimaryIndigoSoft,
            PrimaryIndigo
        )
        else -> Quadruple(
            "Para Revenda",
            Icons.Outlined.SwapHoriz,
            WarningAmberSoft,
            WarningAmber
        )
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .padding(horizontal = if (isCompact) 6.dp else 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(if (isCompact) 10.dp else 12.dp)
        )
        if (!isCompact) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = tint
            )
        }
    }
}

@Composable
fun CardStatusIndicator(
    status: CardStatus,
    purpose: CardPurpose
) {
    val (text, color) = when (status) {
        CardStatus.LISTED -> "À venda" to WarningAmber
        CardStatus.SOLD -> "Vendida" to SuccessGreen
        CardStatus.KEPT -> if (purpose == CardPurpose.PERSONAL) "Na coleção" to PrimaryIndigo else "Por anunciar" to WarningAmber
    }

    Text(
        text = text,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = color
    )
}

@Composable
private fun CardMenuDropdown(
    expanded: Boolean,
    card: CardItem,
    onDismiss: () -> Unit,
    onDetailClick: () -> Unit,
    onEditClick: () -> Unit,
    onTogglePurposeClick: () -> Unit,
    onListCardClick: () -> Unit,
    onRegisterSaleClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss
    ) {
        DropdownMenuItem(
            text = { Text("Ver detalhes") },
            onClick = onDetailClick
        )
        DropdownMenuItem(
            text = { Text("Editar carta") },
            onClick = onEditClick
        )

        if (card.status != CardStatus.SOLD) {
            if (card.purpose == CardPurpose.PERSONAL) {
                DropdownMenuItem(
                    text = { Text("Mover para revenda") },
                    onClick = onTogglePurposeClick
                )
            } else {
                DropdownMenuItem(
                    text = { Text("Guardar na coleção") },
                    onClick = onTogglePurposeClick
                )
            }

            if (card.status == CardStatus.KEPT && card.purpose == CardPurpose.RESALE) {
                DropdownMenuItem(
                    text = { Text("Definir preço e anunciar") },
                    onClick = onListCardClick
                )
            }

            DropdownMenuItem(
                text = { Text("Registar venda") },
                onClick = onRegisterSaleClick
            )
        }

        DropdownMenuItem(
            text = { Text("Eliminar", color = Color.Red) },
            onClick = onDeleteClick
        )
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

private fun String?.isNullOrBlank(): Boolean = this == null || this.trim().isEmpty()
