package pt.ubi.di.pdm.cardfolio.ui.screens

import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.ubi.di.pdm.cardfolio.model.CatalogEntry
import pt.ubi.di.pdm.cardfolio.model.CategoryCatalogItem
import pt.ubi.di.pdm.cardfolio.model.CategoryType
import pt.ubi.di.pdm.cardfolio.model.ClubCatalogItem
import pt.ubi.di.pdm.cardfolio.model.CollectionCatalogItem
import pt.ubi.di.pdm.cardfolio.model.PlayerCatalogItem
import pt.ubi.di.pdm.cardfolio.ui.components.DropdownField
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel

/** The four catalog kinds, with the Portuguese texts that change between tabs. */
enum class CatalogType(
    val tabLabel: String,
    val singular: String,
    val searchHint: String,
    val emptyMessage: String,
    val foundSuffix: String,
    val archivedTag: String,
    val deletedMessage: String,
    val savedMessage: String
) {
    CATEGORY("Categorias", "Categoria", "Pesquisar categorias...", "Nenhuma categoria encontrada.", "categorias encontradas", "[Arquivada]", "Categoria eliminada.", "Categoria guardada com sucesso!"),
    COLLECTION("Coleções", "Coleção", "Pesquisar coleções...", "Nenhuma coleção encontrada.", "coleções encontradas", "[Arquivada]", "Coleção eliminada.", "Coleção guardada com sucesso!"),
    PLAYER("Jogadores", "Jogador", "Pesquisar jogadores...", "Nenhum jogador encontrado.", "jogadores encontrados", "[Arquivado]", "Jogador eliminado.", "Jogador guardado com sucesso!"),
    CLUB("Clubes", "Clube", "Pesquisar clubes...", "Nenhum clube encontrado.", "clubes encontrados", "[Arquivado]", "Clube eliminado.", "Clube guardado com sucesso!")
}

/** What one row of the list shows, independent of the catalog kind. */
private data class CatalogRow(
    val id: String,
    val name: String,
    val isArchived: Boolean,
    val details: String?,
    val usage: String,
    val searchText: String,
    val source: CatalogEntry
)

@Composable
fun CatalogManagementScreen(
    viewModel: CardViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val catalogTab by viewModel.catalogTab.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val collections by viewModel.collections.collectAsState()
    val players by viewModel.players.collectAsState()
    val clubs by viewModel.clubs.collectAsState()
    val allCards by viewModel.allCards.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showArchived by remember { mutableStateOf(false) }

    // Editor sheet: type being edited and the existing item (null = new)
    var editorType by remember { mutableStateOf<CatalogType?>(null) }
    var editingItem by remember { mutableStateOf<CatalogEntry?>(null) }
    // Row that could not be deleted because it is in use (offer to archive it)
    var blockedRow by remember { mutableStateOf<CatalogRow?>(null) }

    val type = CatalogType.entries[catalogTab]

    // Expensive: one pass over the related lists per catalog item; cached and refreshed on data changes
    val rows: List<CatalogRow> = remember(type, categories, collections, players, clubs, allCards) {
        when (type) {
            CatalogType.CATEGORY -> {
                val catUsage = HashMap<String, Int>()
                for (c in collections) catUsage.merge(c.categoryId, 1, Int::plus)
                for (p in players) catUsage.merge(p.categoryId, 1, Int::plus)
                for (c in clubs) catUsage.merge(c.categoryId, 1, Int::plus)
                categories.map { cat ->
                    CatalogRow(cat.id, cat.name, cat.isArchived, null,
                        "${catUsage[cat.id] ?: 0} itens associados no catálogo", cat.name, cat)
                }
            }
            CatalogType.COLLECTION -> {
                val cardCount = HashMap<String, Int>()
                for (c in allCards) c.collectionId?.let { cardCount.merge(it, 1, Int::plus) }
                collections.map { col ->
                    val details = listOfNotNull(col.season, col.category, col.manufacturer?.takeIf { it.isNotBlank() }).joinToString(" · ")
                    CatalogRow(col.id, col.name, col.isArchived, details,
                        "${cardCount[col.id] ?: 0} cartas associadas", "${col.name} ${col.season}", col)
                }
            }
            CatalogType.PLAYER -> {
                val cardCount = HashMap<String, Int>()
                for (c in allCards) c.playerId?.let { cardCount.merge(it, 1, Int::plus) }
                players.map { p ->
                    val details = listOfNotNull(p.sport, p.country?.takeIf { it.isNotBlank() }).joinToString(" · ")
                    CatalogRow(p.id, p.name, p.isArchived, details, "${cardCount[p.id] ?: 0} cartas associadas", p.name, p)
                }
            }
            CatalogType.CLUB -> {
                val cardCount = HashMap<String, Int>()
                for (c in allCards) c.clubId?.let { cardCount.merge(it, 1, Int::plus) }
                clubs.map { c ->
                    val details = listOfNotNull(c.sport, c.country?.takeIf { it.isNotBlank() }).joinToString(" · ")
                    CatalogRow(c.id, c.name, c.isArchived, details, "${cardCount[c.id] ?: 0} cartas associadas", c.name, c)
                }
            }
        }
    }
    val visibleRows = remember(rows, showArchived, searchQuery) {
        rows.filter { (showArchived || !it.isArchived) && it.searchText.contains(searchQuery, ignoreCase = true) }
    }
    val counts = listOf(categories.size, collections.size, players.size, clubs.size)

    fun delete(row: CatalogRow) = viewModel.deleteCatalogEntry(row.source) { deleted ->
        if (deleted) Toast.makeText(context, type.deletedMessage, Toast.LENGTH_SHORT).show() else blockedRow = row
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 32.dp)
    ) {
        Surface(modifier = Modifier.fillMaxWidth(), color = SurfaceWhite) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(imageVector = Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Voltar", tint = TextPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Gerir catálogo", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
        }

        TabRow(
            selectedTabIndex = catalogTab,
            containerColor = SurfaceWhite,
            contentColor = PrimaryIndigo,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[catalogTab]),
                    color = PrimaryIndigo
                )
            }
        ) {
            CatalogType.entries.forEachIndexed { index, tabType ->
                Tab(
                    selected = catalogTab == index,
                    onClick = { viewModel.setCatalogTab(index); searchQuery = "" },
                    text = { Text("${tabType.tabLabel} (${counts[index]})", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(type.searchHint, fontSize = 13.sp) },
                    leadingIcon = { Icon(imageVector = Icons.Outlined.Search, contentDescription = null, tint = TextMuted) },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = { editingItem = null; editorType = type },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo, contentColor = Color.White),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Outlined.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = type.singular, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "${visibleRows.size} ${type.foundSuffix}", fontSize = 12.sp, color = TextSecondary)
                TextButton(onClick = { showArchived = !showArchived }) {
                    Text(
                        text = if (showArchived) "Ocultar arquivados" else "Mostrar arquivados",
                        fontSize = 12.sp,
                        color = PrimaryIndigo,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            LazyColumn(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (visibleRows.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                            Text(text = type.emptyMessage, fontSize = 13.sp, color = TextMuted)
                        }
                    }
                } else {
                    items(visibleRows, key = { it.id }) { row ->
                        CatalogItemRow(
                            row = row,
                            archivedTag = type.archivedTag,
                            onEdit = { editingItem = row.source; editorType = type },
                            onToggleArchive = { viewModel.toggleArchive(row.source) },
                            onDelete = { delete(row) }
                        )
                    }
                }
            }
        }
    }

    editorType?.let { editType ->
        CatalogEditorBottomSheet(
            type = editType,
            existing = editingItem,
            availableCategories = categories.filter { !it.isArchived },
            onDismiss = { editorType = null },
            onSave = { item ->
                viewModel.saveCatalogEntry(item)
                editorType = null
                Toast.makeText(context, editType.savedMessage, Toast.LENGTH_SHORT).show()
            }
        )
    }

    blockedRow?.let { row ->
        AlertDialog(
            onDismissRequest = { blockedRow = null },
            title = { Text("Impossível eliminar") },
            text = { Text("O registo \"${row.name}\" está a ser utilizado. Para manter a integridade dos dados, não pode ser eliminado. Desejas arquivá-lo?") },
            confirmButton = {
                Button(
                    onClick = {
                        if (!row.isArchived) viewModel.toggleArchive(row.source)
                        blockedRow = null
                        Toast.makeText(context, "Registo arquivado com sucesso.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                ) {
                    Text("Arquivar Registo", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { blockedRow = null }) { Text("Cancelar") }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun CatalogItemRow(
    row: CatalogRow,
    archivedTag: String,
    onEdit: () -> Unit,
    onToggleArchive: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)

    Surface(
        modifier = Modifier.fillMaxWidth().clip(shape).border(1.dp, BorderSubtle, shape),
        color = SurfaceWhite
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = row.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    if (row.isArchived) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = archivedTag, fontSize = 10.sp, color = Color.Red, fontWeight = FontWeight.SemiBold)
                    }
                }
                row.details?.let {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = it, fontSize = 11.sp, color = TextSecondary)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = row.usage, fontSize = 10.sp, color = TextMuted)
            }

            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(imageVector = Icons.Outlined.MoreVert, contentDescription = "Mais opções", tint = TextSecondary)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("Editar") }, onClick = { menuExpanded = false; onEdit() })
                    DropdownMenuItem(text = { Text(if (row.isArchived) "Reativar" else "Arquivar") }, onClick = { menuExpanded = false; onToggleArchive() })
                    DropdownMenuItem(text = { Text("Eliminar", color = Color.Red) }, onClick = { menuExpanded = false; onDelete() })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CatalogEditorBottomSheet(
    type: CatalogType,
    existing: CatalogEntry?,
    availableCategories: List<CategoryCatalogItem>,
    onDismiss: () -> Unit,
    onSave: (CatalogEntry) -> Unit
) {
    val category = existing as? CategoryCatalogItem
    val collection = existing as? CollectionCatalogItem
    val player = existing as? PlayerCatalogItem
    val club = existing as? ClubCatalogItem

    var name by remember { mutableStateOf(category?.name ?: collection?.name ?: player?.name ?: club?.name ?: "") }
    var season by remember { mutableStateOf(collection?.season ?: "2024/25") }
    var categoryType by remember { mutableStateOf(category?.type ?: CategoryType.SPORT) }
    var categoryId by remember {
        mutableStateOf(collection?.categoryId ?: player?.categoryId ?: club?.categoryId ?: availableCategories.firstOrNull()?.id ?: "")
    }
    var manufacturer by remember { mutableStateOf(collection?.manufacturer ?: "") }
    var country by remember { mutableStateOf(player?.country ?: club?.country ?: "") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = SurfaceWhite
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "${if (existing != null) "Editar" else "Adicionar"} ${type.singular}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nome (obrigatório)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            if (type == CatalogType.CATEGORY) {
                // Tipo da categoria define se mostra "Atletas"/"Clubes" ou "Personagens" nos rankings
                DropdownField(
                    value = categoryType.displayName,
                    options = CategoryType.entries,
                    optionLabel = { it.displayName },
                    onSelect = { categoryType = it },
                    label = "Tipo",
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (type == CatalogType.COLLECTION) {
                OutlinedTextField(
                    value = season,
                    onValueChange = { season = it },
                    label = { Text("Época / Ano (ex: 2024/25)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (type != CatalogType.CATEGORY) {
                DropdownField(
                    value = availableCategories.find { it.id == categoryId }?.name ?: "",
                    options = availableCategories,
                    optionLabel = { it.name },
                    onSelect = { categoryId = it.id },
                    label = if (type == CatalogType.COLLECTION) "Categoria" else "Categoria / Desporto",
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (type == CatalogType.COLLECTION) {
                OutlinedTextField(
                    value = manufacturer,
                    onValueChange = { manufacturer = it },
                    label = { Text("Fabricante (opcional, ex: Panini, Topps)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            } else if (type != CatalogType.CATEGORY) {
                OutlinedTextField(
                    value = country,
                    onValueChange = { country = it },
                    label = { Text("País / Nacionalidade (opcional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text("Cancelar")
                }
                Button(
                    onClick = {
                        val trimmed = name.trim()
                        val item: CatalogEntry = when (type) {
                            CatalogType.CATEGORY -> (category ?: CategoryCatalogItem(name = trimmed, type = categoryType)).copy(name = trimmed, type = categoryType)
                            CatalogType.COLLECTION -> (collection ?: CollectionCatalogItem(name = trimmed, season = "", categoryId = categoryId)).copy(
                                name = trimmed,
                                season = season.trim(),
                                categoryId = categoryId,
                                manufacturer = manufacturer.ifBlank { null }
                            )
                            CatalogType.PLAYER -> (player ?: PlayerCatalogItem(name = trimmed, categoryId = categoryId)).copy(
                                name = trimmed, categoryId = categoryId, country = country.ifBlank { null }
                            )
                            CatalogType.CLUB -> (club ?: ClubCatalogItem(name = trimmed, categoryId = categoryId)).copy(
                                name = trimmed, categoryId = categoryId, country = country.ifBlank { null }
                            )
                        }
                        onSave(item)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo, contentColor = Color.White),
                    enabled = name.isNotBlank() && (type == CatalogType.CATEGORY || categoryId.isNotBlank())
                ) {
                    Text("Guardar", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
