package pt.ubi.di.pdm.cardfolio.data

import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CategoryCatalogItem
import pt.ubi.di.pdm.cardfolio.model.ClubCatalogItem
import pt.ubi.di.pdm.cardfolio.model.CollectionCatalogItem
import pt.ubi.di.pdm.cardfolio.model.PlayerCatalogItem
import kotlin.math.roundToLong

// Conversions between Room rows (data layer) and UI models

/** Euros (UI) <-> cents (database). */
fun Double.toCents(): Long = (this * 100).roundToLong()
fun Long.fromCents(): Double = this / 100.0

const val NO_COLLECTION_EDITION = "Coleção Geral"

fun CardWithNames.toItem() = CardItem(
    id = card.id,
    name = card.name,
    categoryId = card.categoryId,
    category = categoryName,
    edition = if (collectionName != null) "$collectionName · $collectionSeason" else NO_COLLECTION_EDITION,
    date = card.date,
    cost = card.costCents.fromCents(),
    value = card.valueCents.fromCents(),
    purpose = card.purpose,
    status = card.status,
    imageUri = card.imageUri,
    salePrice = card.salePriceCents?.fromCents(),
    saleDate = card.saleDate,
    collectionId = card.collectionId,
    playerId = card.playerId,
    clubId = card.clubId,
    cardNumber = card.cardNumber,
    variant = card.variant,
    isAutograph = card.isAutograph,
    isPatch = card.isPatch,
    isRookie = card.isRookie,
    isNumbered = card.isNumbered,
    numberedCopy = card.numberedCopy,
    numberedTotal = card.numberedTotal,
    additionalCost = card.additionalCostCents.fromCents(),
    platform = card.platform,
    notes = card.notes
)

fun CardItem.toEntity(userId: String) = CardEntity(
    id = id,
    userId = userId,
    categoryId = categoryId,
    collectionId = collectionId,
    playerId = playerId,
    clubId = clubId,
    name = name,
    date = date,
    costCents = cost.toCents(),
    valueCents = value.toCents(),
    additionalCostCents = additionalCost.toCents(),
    purpose = purpose,
    status = status,
    imageUri = imageUri,
    salePriceCents = salePrice?.toCents(),
    saleDate = saleDate,
    cardNumber = cardNumber,
    variant = variant,
    isAutograph = isAutograph,
    isPatch = isPatch,
    isRookie = isRookie,
    isNumbered = isNumbered,
    numberedCopy = numberedCopy,
    numberedTotal = numberedTotal,
    platform = platform,
    notes = notes
)

fun CategoryEntity.toItem() = CategoryCatalogItem(id = id, name = name, type = type, isArchived = isArchived)
fun CategoryCatalogItem.toEntity(userId: String) = CategoryEntity(id = id, userId = userId, name = name, type = type, isArchived = isArchived)

fun CollectionWithCategory.toItem() = CollectionCatalogItem(
    id = collection.id,
    name = collection.name,
    season = collection.season,
    categoryId = collection.categoryId,
    category = categoryName,
    manufacturer = collection.manufacturer,
    isArchived = collection.isArchived
)
fun CollectionCatalogItem.toEntity(userId: String) = CollectionEntity(
    id = id, userId = userId, categoryId = categoryId, name = name, season = season, manufacturer = manufacturer, isArchived = isArchived
)

fun PlayerWithCategory.toItem() = PlayerCatalogItem(
    id = player.id, name = player.name, categoryId = player.categoryId, sport = categoryName, country = player.country, isArchived = player.isArchived
)
fun PlayerCatalogItem.toEntity(userId: String) = PlayerEntity(
    id = id, userId = userId, categoryId = categoryId, name = name, country = country, isArchived = isArchived
)

fun ClubWithCategory.toItem() = ClubCatalogItem(
    id = club.id, name = club.name, categoryId = club.categoryId, sport = categoryName, country = club.country, isArchived = club.isArchived
)
fun ClubCatalogItem.toEntity(userId: String) = ClubEntity(
    id = id, userId = userId, categoryId = categoryId, name = name, country = country, isArchived = isArchived
)
