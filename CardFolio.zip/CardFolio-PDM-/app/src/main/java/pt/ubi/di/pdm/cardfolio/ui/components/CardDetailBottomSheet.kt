package pt.ubi.di.pdm.cardfolio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.Sell
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRed
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreen
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import pt.ubi.di.pdm.cardfolio.util.CardStats.realizedProfit
import pt.ubi.di.pdm.cardfolio.util.CardStats.totalCost
import pt.ubi.di.pdm.cardfolio.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardDetailModalBottomSheet(
    card: CardItem,
    onDismiss: () -> Unit,
    onEditClick: () -> Unit,
    onTogglePurposeClick: () -> Unit,
    onListCardClick: () -> Unit,
    onRegisterSaleClick: () -> Unit,
    onRevertSaleClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Detalhes da Carta",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Fechar",
                        tint = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Card Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.3f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(TagBackground)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (!card.imageUri.isNullOrEmpty()) {
                    AsyncImage(
                        model = card.imageUri,
                        contentDescription = card.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.Style,
                            contentDescription = null,
                            tint = PrimaryIndigo,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = card.category,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }
                }

                // Badges
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                ) {
                    CardPurposeBadge(purpose = card.purpose, status = card.status)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Title & Info
            Text(
                text = card.name,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = card.edition,
                fontSize = 14.sp,
                color = TextSecondary
            )

            // Characteristics summary chips if any
            if (card.isAutograph || card.isPatch || card.isRookie || card.isNumbered || !card.variant.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (card.isAutograph) CharacteristicChip("Autógrafo")
                    if (card.isPatch) CharacteristicChip("Patch")
                    if (card.isRookie) CharacteristicChip("Rookie")
                    if (card.isNumbered) CharacteristicChip("Num: ${card.numberedCopy}/${card.numberedTotal}")
                    if (!card.variant.isNullOrBlank()) CharacteristicChip(card.variant)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Financial Breakdown Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp)),
                color = TagBackground
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Custo", fontSize = 11.sp, color = TextMuted)
                        Text(
                            text = FormatUtils.formatCurrency(card.totalCost),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        if (card.additionalCost > 0) {
                            Text("inclui ${FormatUtils.formatCurrency(card.additionalCost)} extra", fontSize = 10.sp, color = TextMuted)
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val isSold = card.status == CardStatus.SOLD
                        Text(
                            text = if (isSold) "Preço Venda" else if (card.purpose == CardPurpose.PERSONAL) "Valor Estimado" else "Preço Anunciado",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                        val displayPrice = if (isSold) (card.salePrice ?: card.value) else card.value
                        Text(
                            text = FormatUtils.formatCurrency(displayPrice),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSold) SuccessGreen else TextPrimary
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val isSold = card.status == CardStatus.SOLD
                        // sold: realized profit; otherwise: estimated value minus what the card cost
                        val profit = if (isSold) card.realizedProfit else card.value - card.totalCost
                        Text(
                            text = if (isSold) "Lucro Obtido" else "Valorização",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                        Text(
                            text = FormatUtils.formatCurrency(profit, includePlusSign = true),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (profit >= 0) SuccessGreen else LossRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Metadata info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Data de aquisição: ${FormatUtils.formatDateShort(card.date)}",
                    fontSize = 12.sp,
                    color = TextMuted
                )
                CardStatusIndicator(status = card.status, purpose = card.purpose)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onEditClick,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryIndigo,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Outlined.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Editar Carta", color = Color.White)
                    }

                    if (card.status != CardStatus.SOLD) {
                        OutlinedButton(
                            onClick = onTogglePurposeClick,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (card.purpose == CardPurpose.PERSONAL) Icons.Outlined.SwapHoriz else Icons.Outlined.Favorite,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (card.purpose == CardPurpose.PERSONAL) "Para Revenda" else "Na Coleção")
                        }
                    }
                }

                if (card.status == CardStatus.SOLD) {
                    Button(
                        onClick = onRevertSaleClick,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WarningAmber,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Outlined.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reverter Venda", color = Color.White)
                    }
                } else {
                    if (card.status == CardStatus.KEPT && card.purpose == CardPurpose.RESALE) {
                        Button(
                            onClick = onListCardClick,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WarningAmber,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(imageVector = Icons.Outlined.Sell, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Definir preço e anunciar", color = Color.White)
                        }
                    }

                    Button(
                        onClick = onRegisterSaleClick,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuccessGreen,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Outlined.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Registar Venda Concluída", color = Color.White)
                    }
                }

                OutlinedButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)
                ) {
                    Icon(imageVector = Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Eliminar Carta")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun CharacteristicChip(label: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(PrimaryIndigoSoft)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PrimaryIndigo)
    }
}
