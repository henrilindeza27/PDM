package pt.ubi.di.pdm.cardfolio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Sell
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.ui.components.CardStatusIndicator
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRed
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreen
import pt.ubi.di.pdm.cardfolio.ui.components.ResponsiveContainer
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmberSoft
import pt.ubi.di.pdm.cardfolio.util.CardStats.realizedProfit
import pt.ubi.di.pdm.cardfolio.util.FormatUtils
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel

private data class ResaleCounts(val all: Int, val listed: Int, val stock: Int, val sold: Int)

@Composable
fun ResaleScreen(
    viewModel: CardViewModel,
    modifier: Modifier = Modifier
) {
    val resaleCards by viewModel.filteredResaleCards.collectAsState()
    val allCards by viewModel.allCards.collectAsState()
    val resaleTab by viewModel.resaleTab.collectAsState()
    val resaleProfit by viewModel.resaleProfit.collectAsState()
    val resaleStockInvestment by viewModel.resaleStockInvestment.collectAsState()

    // Single pass instead of four count{} iterations on recomposition
    val (resaleAllCount, listedCount, stockCount, soldCount) = remember(allCards) {
        var all = 0; var listed = 0; var stock = 0; var sold = 0
        for (c in allCards) if (c.purpose == CardPurpose.RESALE) {
            all++
            when (c.status) {
                CardStatus.LISTED -> listed++
                CardStatus.KEPT -> stock++
                CardStatus.SOLD -> sold++
            }
        }
        ResaleCounts(all, listed, stock, sold)
    }

    ResponsiveContainer(modifier = modifier) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Title Block
        item {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                Text(
                    text = "A tua revenda",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "O motor financeiro para expandir a tua coleção pessoal.",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        // Resale Summary Banner Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(PrimaryIndigoSoft, WarningAmberSoft)
                        )
                    )
                    .border(1.dp, PrimaryIndigo.copy(alpha = 0.15f), RoundedCornerShape(16.dp)),
                color = Color.Transparent
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Lucro Realizado",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = FormatUtils.formatCurrency(resaleProfit, includePlusSign = true),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = SuccessGreen
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Capital em Stock",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = FormatUtils.formatCurrency(resaleStockInvestment),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
            }
        }

        // Tabs
        item {
            TabRow(
                selectedTabIndex = resaleTab,
                containerColor = SurfaceWhite,
                contentColor = PrimaryIndigo,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[resaleTab]),
                        color = PrimaryIndigo
                    )
                }
            ) {
                Tab(
                    selected = resaleTab == 0,
                    onClick = { viewModel.setResaleTab(0) },
                    text = { Text("Todas ($resaleAllCount)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = resaleTab == 1,
                    onClick = { viewModel.setResaleTab(1) },
                    text = { Text("À venda ($listedCount)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = resaleTab == 2,
                    onClick = { viewModel.setResaleTab(2) },
                    text = { Text("Por anunciar ($stockCount)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = resaleTab == 3,
                    onClick = { viewModel.setResaleTab(3) },
                    text = { Text("Vendidas ($soldCount)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        // Resale Card Items List
        if (resaleCards.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Sem cartas nesta categoria de revenda.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            items(resaleCards, key = { it.id }) { card ->
                ResaleCardRow(
                    card = card,
                    onClick = { viewModel.openCardDetail(card) },
                    onListCardClick = { viewModel.promptListCard(card) },
                    onRegisterSaleClick = { viewModel.promptRegisterSale(card) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
    }
}

@Composable
private fun ResaleCardRow(
    card: CardItem,
    onClick: () -> Unit,
    onListCardClick: () -> Unit,
    onRegisterSaleClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        color = SurfaceWhite
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Thumbnail with status accent dot
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TagBackground),
                    contentAlignment = Alignment.Center
                ) {
                    if (!card.imageUri.isNullOrEmpty()) {
                        AsyncImage(
                            model = card.imageUri,
                            contentDescription = card.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Style,
                            contentDescription = null,
                            tint = PrimaryIndigo,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Info
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = card.category.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryIndigo,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(PrimaryIndigoSoft)
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = card.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = card.edition,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Price & Status
                Column(horizontalAlignment = Alignment.End) {
                    if (card.status == CardStatus.SOLD) {
                        val salePrice = card.salePrice ?: card.value
                        val profit = card.realizedProfit
                        Text(
                            text = FormatUtils.formatCurrency(salePrice),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = SuccessGreen
                        )
                        Text(
                            text = FormatUtils.formatCurrency(profit, includePlusSign = true),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (profit < 0) LossRed else SuccessGreen
                        )
                    } else {
                        Text(
                            text = FormatUtils.formatCurrency(card.value),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        CardStatusIndicator(status = card.status, purpose = card.purpose)
                    }
                }
            }

            // Quick Actions Row if not sold
            if (card.status != CardStatus.SOLD) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (card.status == CardStatus.KEPT) {
                        OutlinedButton(
                            onClick = onListCardClick,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Outlined.Sell, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Anunciar Preço", fontSize = 11.sp, color = TextPrimary)
                        }
                    }

                    Button(
                        onClick = onRegisterSaleClick,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuccessGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp).let { Modifier })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Registar Venda",
                            fontSize = 11.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
