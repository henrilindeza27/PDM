package pt.ubi.di.pdm.cardfolio.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Schema history is exported to app/schemas.
 * v1 -> v2: categories referenced by id, foreign keys and indices, money in cents,
 * hashed passwords. Old data is discarded (destructive migration, development data only).
 */
@Database(
    entities = [
        UserEntity::class,
        CardEntity::class,
        CategoryEntity::class,
        CollectionEntity::class,
        PlayerEntity::class,
        ClubEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class CardDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun cardDao(): CardDao
    abstract fun catalogDao(): CatalogDao

    companion object {
        @Volatile
        private var INSTANCE: CardDatabase? = null

        fun getDatabase(context: Context): CardDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CardDatabase::class.java,
                    "cardfolio_database"
                )
                    // shortcut: wipes the data on schema changes; write Migration objects before real users exist
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .addCallback(SeedCallback())
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }

    /**
     * Fills a freshly created (or wiped) database with the demo data. The insert happens in onOpen,
     * which runs on the opening connection before any query, so the demo login works immediately.
     */
    private class SeedCallback : Callback() {
        private var needsSeed = false

        override fun onCreate(db: SupportSQLiteDatabase) {
            needsSeed = true
        }

        // A destructive migration recreates the tables without calling onCreate
        override fun onDestructiveMigration(db: SupportSQLiteDatabase) {
            needsSeed = true
        }

        override fun onOpen(db: SupportSQLiteDatabase) {
            if (needsSeed) {
                needsSeed = false
                DemoSeed.insertInto(db)
            }
        }
    }
}
