package pt.ubi.di.pdm.cardfolio.data

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.model.CatalogEntry
import pt.ubi.di.pdm.cardfolio.model.CategoryCatalogItem
import pt.ubi.di.pdm.cardfolio.model.CategoryType
import pt.ubi.di.pdm.cardfolio.model.ClubCatalogItem
import pt.ubi.di.pdm.cardfolio.model.CollectionCatalogItem
import pt.ubi.di.pdm.cardfolio.model.PlayerCatalogItem
import pt.ubi.di.pdm.cardfolio.util.PasswordHasher
import java.util.UUID

/**
 * Single source of truth for the app data. Exposes cold Flows for the current user
 * and suspend functions for writes; callers decide the coroutine scope (ViewModel).
 */
@OptIn(ExperimentalCoroutinesApi::class)
class CardRepository(context: Context) {

    private val database = CardDatabase.getDatabase(context)
    private val cardDao = database.cardDao()
    private val catalogDao = database.catalogDao()
    private val userDao = database.userDao()

    // Remembers the logged-in user and settings between app launches
    private val sessionPrefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)

    val isDarkMode: Boolean
        get() = sessionPrefs.getBoolean(KEY_DARK_MODE, false)

    fun setDarkMode(enabled: Boolean) {
        sessionPrefs.edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }

    val hideCurrencyValues: Boolean
        get() = sessionPrefs.getBoolean(KEY_HIDE_CURRENCY, false)

    fun setHideCurrencyValues(hide: Boolean) {
        sessionPrefs.edit().putBoolean(KEY_HIDE_CURRENCY, hide).apply()
    }

    private val _currentUserId = MutableStateFlow(sessionPrefs.getString(KEY_USER_ID, null) ?: "")
    val currentUserId: StateFlow<String> = _currentUserId.asStateFlow()

    val hasSavedSession: Boolean get() = _currentUserId.value.isNotEmpty()

    private val userId: String get() = _currentUserId.value

    private fun setCurrentUser(userId: String) {
        _currentUserId.value = userId
        sessionPrefs.edit().putString(KEY_USER_ID, userId).apply()
    }

    fun logout() {
        _currentUserId.value = ""
        sessionPrefs.edit().remove(KEY_USER_ID).apply()
    }

    // Data streams, re-subscribed whenever the logged-in user changes
    val cards: Flow<List<CardItem>> = _currentUserId
        .flatMapLatest { cardDao.getCardsForUser(it) }
        .map { list -> list.map { it.toItem() } }

    val categories: Flow<List<CategoryCatalogItem>> = _currentUserId
        .flatMapLatest { catalogDao.getCategoriesForUser(it) }
        .map { list -> list.map { it.toItem() } }

    val collections: Flow<List<CollectionCatalogItem>> = _currentUserId
        .flatMapLatest { catalogDao.getCollectionsForUser(it) }
        .map { list -> list.map { it.toItem() } }

    val players: Flow<List<PlayerCatalogItem>> = _currentUserId
        .flatMapLatest { catalogDao.getPlayersForUser(it) }
        .map { list -> list.map { it.toItem() } }

    val clubs: Flow<List<ClubCatalogItem>> = _currentUserId
        .flatMapLatest { catalogDao.getClubsForUser(it) }
        .map { list -> list.map { it.toItem() } }

    // Auth (password hashing is CPU-heavy, so it runs on Dispatchers.Default)
    suspend fun login(email: String, password: String): UserEntity? {
        val user = userDao.getUserByEmail(email.trim().lowercase()) ?: return null
        val valid = withContext(Dispatchers.Default) { PasswordHasher.verify(password, user.passwordHash) }
        if (!valid) return null
        setCurrentUser(user.id)
        return user
    }

    suspend fun register(name: String, email: String, password: String): UserEntity? {
        val normalizedEmail = email.trim().lowercase()
        if (userDao.getUserByEmail(normalizedEmail) != null) return null

        val newUser = UserEntity(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            email = normalizedEmail,
            passwordHash = withContext(Dispatchers.Default) { PasswordHasher.hash(password) }
        )
        // User and its default categories are created together or not at all
        database.withTransaction {
            userDao.insertUser(newUser)
            DEFAULT_CATEGORIES.forEach { catName ->
                catalogDao.upsertCategory(CategoryEntity(id = UUID.randomUUID().toString(), userId = newUser.id, name = catName, type = CategoryType.OTHER))
            }
        }
        setCurrentUser(newUser.id)
        return newUser
    }

    suspend fun getUser(userId: String): UserEntity? = userDao.getUserById(userId)

    suspend fun updateProfile(userId: String, name: String, photoUri: String?) {
        val user = userDao.getUserById(userId) ?: return
        userDao.updateUser(user.copy(name = name.trim(), photoUri = photoUri))
    }

    suspend fun updatePassword(userId: String, currentPass: String, newPass: String): Boolean {
        val user = userDao.getUserById(userId) ?: return false
        val newHash = withContext(Dispatchers.Default) {
            if (PasswordHasher.verify(currentPass, user.passwordHash)) PasswordHasher.hash(newPass) else null
        } ?: return false
        return userDao.updateUser(user.copy(passwordHash = newHash)) > 0
    }

    /** Deletes the logged-in user; foreign keys cascade to all their cards and catalog. */
    suspend fun deleteAccount() {
        userDao.deleteUser(userId)
        logout()
    }

    // Cards
    suspend fun saveCard(card: CardItem) = cardDao.upsertCard(card.toEntity(userId))

    suspend fun deleteCard(id: String) = cardDao.deleteCard(id)

    /** Reads the stored card, applies [change] and saves it back. */
    private suspend fun updateCard(id: String, change: (CardEntity) -> CardEntity) {
        val card = cardDao.getCardById(id) ?: return
        cardDao.upsertCard(change(card))
    }

    suspend fun listCard(id: String, listPrice: Double) = updateCard(id) {
        it.copy(valueCents = listPrice.toCents(), status = CardStatus.LISTED, purpose = CardPurpose.RESALE)
    }

    suspend fun registerSale(id: String, salePrice: Double, saleDate: String) = updateCard(id) {
        it.copy(salePriceCents = salePrice.toCents(), saleDate = saleDate, status = CardStatus.SOLD, purpose = CardPurpose.RESALE)
    }

    suspend fun revertSale(id: String) = updateCard(id) {
        it.copy(status = CardStatus.KEPT, salePriceCents = null, saleDate = null)
    }

    suspend fun moveToResale(id: String) = updateCard(id) {
        it.copy(purpose = CardPurpose.RESALE, status = if (it.status == CardStatus.SOLD) CardStatus.SOLD else CardStatus.KEPT)
    }

    suspend fun moveToPersonal(id: String) = updateCard(id) {
        it.copy(purpose = CardPurpose.PERSONAL, status = CardStatus.KEPT)
    }

    // Catalog: save = insert or update
    suspend fun saveCatalogEntry(entry: CatalogEntry) = when (entry) {
        is CategoryCatalogItem -> catalogDao.upsertCategory(entry.toEntity(userId))
        is CollectionCatalogItem -> catalogDao.upsertCollection(entry.toEntity(userId))
        is PlayerCatalogItem -> catalogDao.upsertPlayer(entry.toEntity(userId))
        is ClubCatalogItem -> catalogDao.upsertClub(entry.toEntity(userId))
    }

    /** Returns false (and deletes nothing) when the entry is still referenced. */
    suspend fun deleteCatalogEntry(entry: CatalogEntry): Boolean {
        val usage = when (entry) {
            is CategoryCatalogItem -> catalogDao.countCategoryUsage(entry.id)
            is CollectionCatalogItem -> cardDao.countByCollection(entry.id)
            is PlayerCatalogItem -> cardDao.countByPlayer(entry.id)
            is ClubCatalogItem -> cardDao.countByClub(entry.id)
        }
        if (usage > 0) return false
        when (entry) {
            is CategoryCatalogItem -> catalogDao.deleteCategory(entry.id)
            is CollectionCatalogItem -> catalogDao.deleteCollection(entry.id)
            is PlayerCatalogItem -> catalogDao.deletePlayer(entry.id)
            is ClubCatalogItem -> catalogDao.deleteClub(entry.id)
        }
        return true
    }

    private companion object {
        const val KEY_USER_ID = "user_id"
        const val KEY_DARK_MODE = "dark_mode"
        const val KEY_HIDE_CURRENCY = "hide_currency"
        val DEFAULT_CATEGORIES = listOf("Futebol", "Pokémon", "Basquetebol", "Ténis", "Outros")
    }
}
