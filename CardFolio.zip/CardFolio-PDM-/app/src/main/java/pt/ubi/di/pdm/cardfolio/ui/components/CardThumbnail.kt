package pt.ubi.di.pdm.cardfolio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground

/** Small square card picture, or a card icon when the card has no image. */
@Composable
fun CardThumbnail(card: CardItem, size: Dp, borderColor: Color = BorderSubtle, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(size / 5)
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(TagBackground)
            .border(1.dp, borderColor, shape),
        contentAlignment = Alignment.Center
    ) {
        if (!card.imageUri.isNullOrBlank()) {
            AsyncImage(
                model = card.imageUri,
                contentDescription = card.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
        } else {
            Icon(imageVector = Icons.Outlined.Style, contentDescription = null, tint = PrimaryIndigo, modifier = Modifier.size(size / 2))
        }
    }
}
