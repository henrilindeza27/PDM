package pt.ubi.di.pdm.cardfolio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.ui.components.KpiBar
import pt.ubi.di.pdm.cardfolio.ui.components.ResponsiveContainer
import pt.ubi.di.pdm.cardfolio.ui.components.SectionCard
import pt.ubi.di.pdm.cardfolio.ui.components.TopValuableCardsPodium
import pt.ubi.di.pdm.cardfolio.ui.theme.*
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRed
import pt.ubi.di.pdm.cardfolio.util.CardStats.realizedProfit
import pt.ubi.di.pdm.cardfolio.util.FormatUtils
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel
import kotlin.math.abs

@Composable
fun DashboardScreen(
    viewModel: CardViewModel,
    onNavigateToCollection: () -> Unit,
    onNavigateToResale: () -> Unit,
    onNavigateToStats: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allCards by viewModel.allCards.collectAsState()
    val collectionValue by viewModel.collectionValue.collectAsState()
    val personalInvestment by viewModel.personalInvestment.collectAsState()
    val personalCollection by viewModel.personalCollection.collectAsState()
    val categories by viewModel.availableCategories.collectAsState()
    val resaleProfit by viewModel.resaleProfit.collectAsState()
    val resaleCompletedSalesCount by viewModel.resaleCompletedSalesCount.collectAsState()
    val resaleStockCount by viewModel.resaleStockCount.collectAsState()
    val resaleStockInvestment by viewModel.resaleStockInvestment.collectAsState()
    val appreciationPercentage by viewModel.appreciationPercentage.collectAsState()
    val userName by viewModel.userName.collectAsState()

    val recentlyAdded = remember(allCards) { allCards.sortedByDescending { it.date }.take(6) }
    val latestSales = remember(allCards) {
        allCards.filter { it.status == CardStatus.SOLD }.sortedByDescending { it.saleDate ?: it.date }.take(3)
    }

    ResponsiveContainer(modifier = modifier) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        // Welcome Greeting Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Bem-vindo de volta, $userName",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Aqui tens o resumo da tua coleção, num relance.",
                fontSize = 13.sp,
                color = TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // KPI Bar
        KpiBar(
            collectionValue = collectionValue,
            personalInvestment = personalInvestment,
            personalCardsCount = personalCollection.size,
            categoriesCount = (categories.size - 1).coerceAtLeast(0),
            resaleProfit = resaleProfit,
            resaleCompletedSalesCount = resaleCompletedSalesCount,
            resaleStockCount = resaleStockCount,
            resaleStockInvestment = resaleStockInvestment
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Block 1: Recently Added (Horizontal Slide) & Most Valuable (Podium)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Recently Added (Horizontal Slide)
            SectionCard(
                title = "Adicionadas recentemente",
                action = { SectionAction("Ver coleção", onNavigateToCollection) }
            ) {
                RecentlyAddedHorizontalSlide(
                    cards = recentlyAdded,
                    onCardClick = { card -> viewModel.openCardDetail(card) }
                )
            }

            // Most Valuable (Podium reused from Stats)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TopValuableCardsPodium(
                    cards = personalCollection,
                    onCardClick = { card -> viewModel.openCardDetail(card) }
                )

                // Callout
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(SuccessGreenSoft)
                        .border(1.dp, SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "A tua coleção pessoal ${if (appreciationPercentage < 0) "desvalorizou" else "valorizou"} ${FormatUtils.formatPercent(abs(appreciationPercentage))} desde a compra.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SuccessGreen
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Block 2: Latest Sales & Quick Summary
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Latest Sales
            SectionCard(
                title = "Últimas vendas",
                action = { SectionAction("Ver revenda", onNavigateToResale) }
            ) {
                if (latestSales.isEmpty()) {
                    Text("Ainda não realizaste vendas.", fontSize = 12.sp, color = TextMuted)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        latestSales.forEach { card ->
                            val salePrice = card.salePrice ?: card.value
                            val profit = card.realizedProfit

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(TagBackground)
                                    .clickable { viewModel.openCardDetail(card) }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(SurfaceWhite)
                                        .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (!card.imageUri.isNullOrEmpty()) {
                                        AsyncImage(
                                            model = card.imageUri,
                                            contentDescription = card.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.matchParentSize()
                                        )
                                    } else {
                                        Icon(imageVector = Icons.Outlined.Style, contentDescription = null, tint = PrimaryIndigo, modifier = Modifier.size(18.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = card.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Vendido por ${FormatUtils.formatCurrency(salePrice)}",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }

                                Text(
                                    text = FormatUtils.formatCurrency(profit, includePlusSign = true),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (profit < 0) LossRed else SuccessGreen
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    }
}

/** Header action ("Ver ...") shown on the right of a dashboard section title. */
@Composable
private fun SectionAction(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = PrimaryIndigo)
    }
}

@Composable
private fun RecentlyAddedHorizontalSlide(
    cards: List<CardItem>,
    onCardClick: (CardItem) -> Unit
) {
    if (cards.isEmpty()) {
        Text("Ainda não adicionaste cartas.", fontSize = 12.sp, color = TextMuted)
        return
    }

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(cards, key = { it.id }) { card ->
            Surface(
                modifier = Modifier
                    .width(135.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                    .clickable { onCardClick(card) },
                color = SurfaceWhite
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(TagBackground)
                            .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!card.imageUri.isNullOrEmpty()) {
                            AsyncImage(
                                model = card.imageUri,
                                contentDescription = card.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.matchParentSize()
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.Style,
                                contentDescription = null,
                                tint = PrimaryIndigo,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = card.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = FormatUtils.formatCurrency(card.value),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SuccessGreen
                    )
                }
            }
        }
    }
}
