package pt.ubi.di.pdm.cardfolio.util

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

object ImageStorage {

    /**
     * Copies a picked image into the app's private storage and returns its file URI,
     * so it keeps loading after restarts even if the original is moved or deleted.
     * shortcut: replaced/deleted cards leave their old file behind, clean up if storage becomes an issue
     */
    suspend fun copyToAppStorage(context: Context, source: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "images").apply { mkdirs() }
            val target = File(dir, "${UUID.randomUUID()}.jpg")
            val input = context.contentResolver.openInputStream(source) ?: error("Sem acesso à imagem")
            input.use { inStream -> target.outputStream().use { inStream.copyTo(it) } }
            Uri.fromFile(target).toString()
        }.getOrNull()
    }
}
