package pt.ubi.di.pdm.cardfolio.util

import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.model.SalesPeriod
import java.time.LocalDate
import java.time.YearMonth

/** One line of a "top N" ranking: label, number of cards and money invested in them. */
data class RankingEntry(val label: String, val count: Int, val invested: Double)

/** Personal collection at the end of [month]: total invested and current estimated value. */
data class GrowthPoint(val month: YearMonth, val invested: Double, val value: Double)

/** What happened in [month]: cards bought (and their cost) and resales completed. */
data class MonthActivity(
    val month: YearMonth,
    val bought: Int,
    val spent: Double,
    val sold: Int,
    val revenue: Double,
    val profit: Double
)

/** Pure calculations used by the dashboards (no Android dependencies, unit-tested). */
object CardStats {

    val CardItem.totalCost: Double get() = cost + additionalCost

    val CardItem.realizedProfit: Double get() = (salePrice ?: value) - totalCost

    fun soldInPeriod(cards: List<CardItem>, period: SalesPeriod, today: LocalDate = LocalDate.now()): List<CardItem> =
        cards.filter { card ->
            if (card.status != CardStatus.SOLD || card.saleDate.isNullOrBlank()) return@filter false
            val date = runCatching { LocalDate.parse(card.saleDate) }.getOrNull()
            date == null || period.contains(date, today)
        }

    /** Groups cards by [key] (null keys ignored) and returns the biggest groups first. */
    fun ranking(cards: List<CardItem>, key: (CardItem) -> String?, label: (String) -> String): List<RankingEntry> =
        cards.filter { key(it) != null }
            .groupBy { key(it)!! }
            .map { (id, group) -> RankingEntry(label(id), group.size, group.sumOf { it.totalCost }) }
            .sortedByDescending { it.count }

    private fun monthOf(isoDate: String?): YearMonth? =
        isoDate?.let { runCatching { YearMonth.from(LocalDate.parse(it)) }.getOrNull() }

    private fun monthsBetween(from: YearMonth, to: YearMonth): List<YearMonth> =
        generateSequence(from) { it.plusMonths(1) }.takeWhile { !it.isAfter(to) }.toList()

    /**
     * Personal collection month by month: what had been invested and the current estimated value
     * of the cards owned at the end of each month. Starts at zero the month before the first purchase.
     */
    fun personalGrowth(cards: List<CardItem>, today: LocalDate = LocalDate.now()): List<GrowthPoint> {
        val personal = cards.filter { it.purpose == CardPurpose.PERSONAL }.mapNotNull { card -> monthOf(card.date)?.let { it to card } }
        val first = personal.minOfOrNull { it.first } ?: return emptyList()
        return monthsBetween(first.minusMonths(1), YearMonth.from(today)).map { month ->
            val owned = personal.filter { !it.first.isAfter(month) }.map { it.second }
            GrowthPoint(month, owned.sumOf { it.totalCost }, owned.sumOf { it.value })
        }
    }

    /** Purchases and completed sales per month, from the first activity until the current month. */
    fun monthlyActivity(cards: List<CardItem>, today: LocalDate = LocalDate.now()): List<MonthActivity> {
        val bought = cards.mapNotNull { card -> monthOf(card.date)?.let { it to card } }
        val sold = cards.filter { it.status == CardStatus.SOLD }.mapNotNull { card -> monthOf(card.saleDate)?.let { it to card } }
        val first = (bought + sold).minOfOrNull { it.first } ?: return emptyList()
        return monthsBetween(first, maxOf(YearMonth.from(today), (bought + sold).maxOf { it.first })).map { month ->
            val boughtNow = bought.filter { it.first == month }.map { it.second }
            val soldNow = sold.filter { it.first == month }.map { it.second }
            MonthActivity(
                month = month,
                bought = boughtNow.size,
                spent = boughtNow.sumOf { it.totalCost },
                sold = soldNow.size,
                revenue = soldNow.sumOf { it.salePrice ?: it.value },
                profit = soldNow.sumOf { it.realizedProfit }
            )
        }
    }

    fun toCsv(cards: List<CardItem>): String = buildString {
        append("ID,Nome,Edição,Categoria,Data,Custo,Valor,Finalidade,Estado,PreçoVenda,DataVenda\n")
        cards.forEach { c ->
            append(
                listOf(
                    q(c.id), q(c.name), q(c.edition), q(c.category), q(c.date), c.cost, c.value,
                    q(c.purpose.name), q(c.status.name), c.salePrice ?: "", q(c.saleDate)
                ).joinToString(",")
            ).append("\n")
        }
    }

    // CSV quoting: doubles inner quotes so a name like Ronaldo "CR7" doesn't break the columns
    private fun q(field: String?) = "\"" + (field ?: "").replace("\"", "\"\"") + "\""
}
