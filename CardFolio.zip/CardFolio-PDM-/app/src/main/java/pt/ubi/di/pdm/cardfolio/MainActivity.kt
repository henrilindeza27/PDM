package pt.ubi.di.pdm.cardfolio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import pt.ubi.di.pdm.cardfolio.navigation.CardfolioApp
import pt.ubi.di.pdm.cardfolio.ui.theme.CardFolioTheme
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: CardViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsState()
            CardFolioTheme(darkTheme = isDarkMode) {
                CardfolioApp(viewModel = viewModel)
            }
        }
    }
}
