package pt.ubi.di.pdm.cardfolio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.MilitaryTech
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.ubi.di.pdm.cardfolio.model.ALL_CATEGORIES
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CategoryType
import pt.ubi.di.pdm.cardfolio.model.StatsPurpose
import pt.ubi.di.pdm.cardfolio.ui.components.CardThumbnail
import pt.ubi.di.pdm.cardfolio.ui.components.DropdownField
import pt.ubi.di.pdm.cardfolio.ui.components.ResponsiveContainer
import pt.ubi.di.pdm.cardfolio.ui.components.SectionCard
import pt.ubi.di.pdm.cardfolio.ui.components.TopValuableCardsPodium
import pt.ubi.di.pdm.cardfolio.ui.theme.AccentGreen
import pt.ubi.di.pdm.cardfolio.ui.theme.AccentGreenSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.InfoBlue
import pt.ubi.di.pdm.cardfolio.ui.theme.InfoBlueSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.MedalGold
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmberSoft
import pt.ubi.di.pdm.cardfolio.util.CardStats
import pt.ubi.di.pdm.cardfolio.util.FormatUtils
import pt.ubi.di.pdm.cardfolio.util.RankingEntry
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel

private val SPORTS_WITH_PLAYERS = setOf("futebol", "basquetebol")

@Composable
fun StatsScreen(
    viewModel: CardViewModel,
    modifier: Modifier = Modifier
) {
    val statsTab by viewModel.statsTab.collectAsState()
    val tabTitles = listOf("Coleção", "Finanças", "Evolução")

    ResponsiveContainer(modifier = modifier) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 32.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text(text = "A tua coleção, em detalhe", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "Análise multidimensional de inventário, finanças e evolução.", fontSize = 12.sp, color = TextSecondary)
        }

        Spacer(modifier = Modifier.height(4.dp))

        TabRow(
            selectedTabIndex = statsTab,
            containerColor = SurfaceWhite,
            contentColor = PrimaryIndigo,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[statsTab]),
                    color = PrimaryIndigo
                )
            }
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = statsTab == index,
                    onClick = { viewModel.setStatsTab(index) },
                    text = { Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (statsTab) {
                0 -> CollectionTab(viewModel)
                1 -> FinanceTab(viewModel)
                else -> EvolutionTab(viewModel)
            }
        }
    }
    }
}

// ---------- Tab 1: Coleção ----------

private data class FeatureCounts(
    val autograph: Int, val patch: Int, val rookie: Int, val numbered: Int, val lowestPrintRun: Int?
)

private enum class RankingKind(val label: String, val icon: ImageVector, val color: Color, val emptyText: String) {
    COLLECTION("Coleções", Icons.Outlined.Style, WarningAmber, "Sem coleções registadas."),
    ATHLETE("Atletas", Icons.Outlined.Person, InfoBlue, "Sem atletas associados."),
    CHARACTER("TCG", Icons.Outlined.AutoAwesome, PrimaryIndigo, "Sem personagens associados."),
    CLUB("Clubes", Icons.Outlined.Shield, AccentGreen, "Sem clubes associados.")
}

@Composable
private fun CollectionTab(viewModel: CardViewModel) {
    val purposeFilter by viewModel.statsPurposeFilter.collectAsState()
    val categoryFilter by viewModel.statsCategoryFilter.collectAsState()
    val availableCategories by viewModel.availableCategories.collectAsState()
    val cards by viewModel.statsInventoryCards.collectAsState()
    val collections by viewModel.collections.collectAsState()
    val players by viewModel.players.collectAsState()
    val clubs by viewModel.clubs.collectAsState()

    // 1. Filtros compactos
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DropdownField(
            value = purposeFilter.label,
            options = StatsPurpose.entries,
            onSelect = viewModel::setStatsPurposeFilter,
            optionLabel = { it.label },
            label = "Finalidade",
            compact = true,
            modifier = Modifier.weight(1f)
        )
        DropdownField(
            value = categoryFilter,
            options = availableCategories,
            onSelect = viewModel::setStatsCategoryFilter,
            label = "Categoria",
            compact = true,
            modifier = Modifier.weight(1f)
        )
    }

    // 2. Resumo da coleção: donut + KPIs com valor estimado em destaque
    val valueTotal = remember(cards) { cards.sumOf { it.value } }
    val showSportsStats = categoryFilter == ALL_CATEGORIES || categoryFilter.lowercase() in SPORTS_WITH_PLAYERS
    val distinctEditions = remember(cards) { cards.map { it.collectionId ?: it.edition }.distinct().size }
    val distinctPlayers = remember(cards) { cards.mapNotNull { it.playerId }.distinct().size }
    val distinctClubs = remember(cards) { cards.mapNotNull { it.clubId }.distinct().size }
    CollectionOverviewCard(
        cards = cards,
        valueTotal = valueTotal,
        distinctEditions = distinctEditions,
        distinctPlayers = distinctPlayers.takeIf { showSportsStats },
        distinctClubs = distinctClubs.takeIf { showSportsStats }
    )

    // 3. Pódio das mais valiosas
    TopValuableCardsPodium(cards = cards, onCardClick = viewModel::openCardDetail)

    // 4. Rankings num só cartão com segmented control, dividido por tipo de categoria
    val allCategories by viewModel.categories.collectAsState()
    val categoryTypeById = remember(allCategories) { allCategories.associate { it.id to it.type } }
    val collectionRanking = remember(cards, collections) {
        CardStats.ranking(cards, key = { it.collectionId ?: it.edition }) { id ->
            collections.find { it.id == id }?.let { "${it.name} · ${it.season}" } ?: id
        }
    }
    // Atletas = players em categorias SPORT; Personagens = players em categorias TCG
    val athleteRanking = remember(cards, players, categoryTypeById) {
        CardStats.ranking(
            cards.filter { card ->
                val p = players.find { it.id == card.playerId }
                p != null && categoryTypeById[p.categoryId] == CategoryType.SPORT
            },
            key = { it.playerId }
        ) { id -> players.find { it.id == id }?.name ?: "Atleta" }
    }
    val characterRanking = remember(cards, players, categoryTypeById) {
        CardStats.ranking(
            cards.filter { card ->
                val p = players.find { it.id == card.playerId }
                p != null && categoryTypeById[p.categoryId] == CategoryType.TCG
            },
            key = { it.playerId }
        ) { id -> players.find { it.id == id }?.name ?: "Personagem" }
    }
    val clubRanking = remember(cards, clubs) {
        CardStats.ranking(cards, key = { it.clubId }) { id -> clubs.find { it.id == id }?.name ?: "Clube" }
    }
    UnifiedRankingSection(
        collection = collectionRanking,
        athlete = athleteRanking,
        character = characterRanking,
        club = clubRanking
    )

    // 5. Características como chips (compacto)
    val features = remember(cards) {
        var auto = 0; var patch = 0; var rookie = 0; var numbered = 0; var minPrint: Int? = null
        for (c in cards) {
            if (c.isAutograph) auto++
            if (c.isPatch) patch++
            if (c.isRookie) rookie++
            if (c.isNumbered) {
                numbered++
                c.numberedTotal?.let { if (minPrint == null || it < minPrint!!) minPrint = it }
            }
        }
        FeatureCounts(auto, patch, rookie, numbered, minPrint)
    }
    if (features.autograph + features.patch + features.rookie + features.numbered > 0) {
        SpecialFeaturesCard(features)
    }

    // 6. Destaques
    val highestCostCard = cards.maxByOrNull { it.cost }
    val highestValueCard = cards.maxByOrNull { it.value }
    val newestCard = cards.maxByOrNull { it.date }
    if (highestCostCard != null && highestValueCard != null && newestCard != null) {
        SectionCard(title = "Destaques da coleção") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HighlightRow("Maior preço de compra", highestCostCard, FormatUtils.formatCurrency(highestCostCard.cost))
                HighlightRow("Maior valor estimado", highestValueCard, FormatUtils.formatCurrency(highestValueCard.value))
                HighlightRow("Aquisição mais recente", newestCard, FormatUtils.formatDateShort(newestCard.date))
            }
        }
    }
}

/** Hero card: valor + barra horizontal empilhada por categoria + chips de KPIs. */
@Composable
private fun CollectionOverviewCard(
    cards: List<CardItem>,
    valueTotal: Double,
    distinctEditions: Int,
    distinctPlayers: Int?,
    distinctClubs: Int?
) {
    val shape = RoundedCornerShape(16.dp)
    val counts = remember(cards) {
        cards.groupBy { it.category }.mapValues { it.value.size }
            .entries.sortedByDescending { it.value }
    }
    Surface(
        modifier = Modifier.fillMaxWidth().clip(shape).border(1.dp, BorderSubtle, shape),
        color = SurfaceWhite
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Valor estimado total", fontSize = 11.sp, color = TextMuted)
            Text(
                text = FormatUtils.formatCurrency(valueTotal),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text("${cards.size} ${if (cards.size == 1) "carta" else "cartas"} no inventário", fontSize = 12.sp, color = TextSecondary)

            if (counts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                CategoryStackedBar(counts = counts, total = cards.size)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KpiChip("Edições", distinctEditions, Icons.Outlined.Style, WarningAmber, Modifier.weight(1f))
                if (distinctPlayers != null) KpiChip("Atletas", distinctPlayers, Icons.Outlined.Person, InfoBlue, Modifier.weight(1f))
                if (distinctClubs != null) KpiChip("Clubes", distinctClubs, Icons.Outlined.Shield, AccentGreen, Modifier.weight(1f))
            }
        }
    }
}

/** Barra horizontal empilhada com legenda abaixo — replaces the donut. */
@Composable
private fun CategoryStackedBar(counts: List<Map.Entry<String, Int>>, total: Int) {
    val palette = listOf(PrimaryIndigo, WarningAmber, InfoBlue, AccentGreen, Color(0xFF8B5CF6), Color(0xFFEC4899))
    val safeTotal = total.coerceAtLeast(1)
    // Barra empilhada
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(TagBackground)
    ) {
        counts.forEachIndexed { index, entry ->
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(entry.value.toFloat() / safeTotal)
                    .background(palette[index % palette.size])
            )
        }
    }
    Spacer(modifier = Modifier.height(8.dp))
    // Legenda em FlowRow equivalente
    counts.chunked(3).forEach { rowItems ->
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            rowItems.forEachIndexed { subIndex, entry ->
                val fullIndex = counts.indexOf(entry)
                val percentage = entry.value.toDouble() / safeTotal * 100
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(palette[fullIndex % palette.size])
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${entry.key} ${FormatUtils.formatPercent(percentage)}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            // preenche espaço se a linha tiver < 3 itens
            repeat(3 - rowItems.size) { Spacer(modifier = Modifier.weight(1f)) }
        }
        Spacer(modifier = Modifier.height(4.dp))
    }
}

@Composable
private fun KpiChip(label: String, value: Int, icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(TagBackground)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 10.sp, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("$value", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
    }
}

/** Rankings in a single card with tabs — only the pills with data appear. */
@Composable
private fun UnifiedRankingSection(
    collection: List<RankingEntry>,
    athlete: List<RankingEntry>,
    character: List<RankingEntry>,
    club: List<RankingEntry>
) {
    val available = buildList {
        add(RankingKind.COLLECTION to collection)
        if (athlete.isNotEmpty()) add(RankingKind.ATHLETE to athlete)
        if (character.isNotEmpty()) add(RankingKind.CHARACTER to character)
        if (club.isNotEmpty()) add(RankingKind.CLUB to club)
    }
    var selectedIndex by remember(available.size) {
        androidx.compose.runtime.mutableStateOf(0)
    }
    if (selectedIndex > available.lastIndex) selectedIndex = 0
    val (selectedKind, selectedEntries) = available[selectedIndex]

    SectionCard(title = "Mais representados", subtitle = "Top 5 por número de cartas") {
        // Segmented pill selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(TagBackground)
                .padding(3.dp)
        ) {
            available.forEachIndexed { index, (kind, _) ->
                val isSelected = index == selectedIndex
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) SurfaceWhite else Color.Transparent)
                        .clickable { selectedIndex = index }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = kind.icon,
                        contentDescription = null,
                        tint = if (isSelected) kind.color else TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = kind.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) TextPrimary else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedEntries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(selectedKind.emptyText, fontSize = 12.sp, color = TextMuted)
            }
        } else {
            val maxCount = selectedEntries.firstOrNull()?.count?.coerceAtLeast(1) ?: 1
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                selectedEntries.take(5).forEachIndexed { index, entry ->
                    RankingRow(index = index, entry = entry, maxCount = maxCount, barColor = selectedKind.color)
                }
            }
        }
    }
}

@Composable
private fun RankingRow(index: Int, entry: RankingEntry, maxCount: Int, barColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(if (index == 0) MedalGold else PrimaryIndigoSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${index + 1}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (index == 0) Color.White else PrimaryIndigo
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = entry.label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = "${entry.count} · ${FormatUtils.formatCurrency(entry.invested)}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary
            )
        }
        ProgressBar(progress = entry.count.toFloat() / maxCount, color = barColor)
    }
}

@Composable
private fun SpecialFeaturesCard(features: FeatureCounts) {
    SectionCard(title = "Atributos especiais") {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Chips em linha: só mostra os que têm valor > 0
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (features.autograph > 0) FeatureChip("Autógrafos", features.autograph, WarningAmber, WarningAmberSoft)
                if (features.patch > 0) FeatureChip("Patches", features.patch, InfoBlue, InfoBlueSoft)
                if (features.rookie > 0) FeatureChip("Rookies", features.rookie, AccentGreen, AccentGreenSoft)
                if (features.numbered > 0) FeatureChip("Numeradas", features.numbered, PrimaryIndigo, PrimaryIndigoSoft)
            }
            features.lowestPrintRun?.let { print ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(PrimaryIndigoSoft)
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Outlined.MilitaryTech, contentDescription = null, tint = PrimaryIndigo, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Menor tiragem conhecida: /$print",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryIndigo
                    )
                }
            }
        }
    }
}

@Composable
private fun FeatureChip(label: String, count: Int, color: Color, background: Color) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(background)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = Icons.Outlined.Star, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
        Spacer(modifier = Modifier.width(5.dp))
        Text("$label · $count", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

// ---------- Building blocks ----------

@Composable
private fun ProgressBar(progress: Float, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(CircleShape)
            .background(TagBackground)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(progress.coerceIn(0.05f, 1f))
                .height(6.dp)
                .clip(CircleShape)
                .background(color)
        )
    }
}

@Composable
private fun IconBadge(icon: ImageVector, tint: Color, background: Color, size: Dp = 32.dp) {
    Box(
        modifier = Modifier.size(size).clip(CircleShape).background(background),
        contentAlignment = Alignment.Center
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(size / 2))
    }
}

@Composable
private fun HighlightRow(label: String, card: CardItem, detail: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            CardThumbnail(card = card, size = 40.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = label, fontSize = 10.sp, color = TextMuted)
                Text(text = card.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = detail, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryIndigo)
    }
}
