package pt.ubi.di.pdm.cardfolio.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true)]
)
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val passwordHash: String, // PBKDF2 "salt:hash", see PasswordHasher
    val photoUri: String? = null
)
