package pt.ubi.di.pdm.cardfolio.ui.components

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel
import java.time.LocalDate

/**
 * Asks the user where to save the CSV file and writes the exported cards to it
 */
@Composable
fun rememberCsvExporter(viewModel: CardViewModel): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val csv = viewModel.exportCsvData()
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val stream = context.contentResolver.openOutputStream(uri) ?: error("Sem acesso ao ficheiro")
                    // BOM so Excel reads the Portuguese accents correctly
                    stream.use { it.write(("﻿" + csv).toByteArray()) }
                }.isSuccess
            }
            val message = if (ok) "Ficheiro CSV exportado com sucesso!" else "Não foi possível exportar o CSV."
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }
    return { launcher.launch("cardfolio_${LocalDate.now()}.csv") }
}
