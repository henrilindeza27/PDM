package pt.ubi.di.pdm.cardfolio.ui.components

import pt.ubi.di.pdm.cardfolio.ui.theme.MedalBronze
import pt.ubi.di.pdm.cardfolio.ui.theme.MedalGold
import pt.ubi.di.pdm.cardfolio.ui.theme.MedalSilver
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.ui.theme.*
import pt.ubi.di.pdm.cardfolio.util.FormatUtils

@Composable
fun TopValuableCardsPodium(
    cards: List<CardItem>,
    onCardClick: (CardItem) -> Unit = {}
) {
    val topCards = cards.sortedByDescending { it.value }.take(3)
    if (topCards.isEmpty()) return

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp)),
        color = SurfaceWhite
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Top 3 — Cartas Mais Valiosas",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Destaques de maior valor estimado no inventário",
                fontSize = 11.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(16.dp))

            val first = topCards.getOrNull(0)
            val second = topCards.getOrNull(1)
            val third = topCards.getOrNull(2)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                if (second != null) {
                    PodiumCardItem(card = second, rank = 2, size = 85.dp, modifier = Modifier.weight(1f), onClick = { onCardClick(second) })
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                if (first != null) {
                    PodiumCardItem(card = first, rank = 1, size = 110.dp, modifier = Modifier.weight(1.2f), onClick = { onCardClick(first) })
                }

                if (third != null) {
                    PodiumCardItem(card = third, rank = 3, size = 85.dp, modifier = Modifier.weight(1f), onClick = { onCardClick(third) })
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun PodiumCardItem(
    card: CardItem,
    rank: Int,
    size: Dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val medalColor = when (rank) {
        1 -> MedalGold
        2 -> MedalSilver
        else -> MedalBronze
    }

    Column(
        modifier = modifier
            .padding(horizontal = 4.dp)
            .clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(12.dp))
                .background(TagBackground)
                .border(
                    width = if (rank == 1) 2.dp else 1.dp,
                    color = medalColor,
                    shape = RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (!card.imageUri.isNullOrEmpty()) {
                AsyncImage(
                    model = card.imageUri,
                    contentDescription = card.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Outlined.Style,
                    contentDescription = null,
                    tint = PrimaryIndigo,
                    modifier = Modifier.size(size * 0.4f)
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(medalColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "#$rank",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = card.name,
            fontSize = if (rank == 1) 12.sp else 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = FormatUtils.formatCurrency(card.value),
            fontSize = if (rank == 1) 12.sp else 11.sp,
            fontWeight = FontWeight.Bold,
            color = SuccessGreen
        )
    }
}
