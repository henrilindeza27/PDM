package pt.ubi.di.pdm.cardfolio.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.cardfolio.data.CardRepository
import pt.ubi.di.pdm.cardfolio.data.UserEntity
import pt.ubi.di.pdm.cardfolio.model.ALL_CATEGORIES
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.model.CatalogEntry
import pt.ubi.di.pdm.cardfolio.model.CategoryCatalogItem
import pt.ubi.di.pdm.cardfolio.model.ClubCatalogItem
import pt.ubi.di.pdm.cardfolio.model.CollectionCatalogItem
import pt.ubi.di.pdm.cardfolio.model.PlayerCatalogItem
import pt.ubi.di.pdm.cardfolio.model.SalesPeriod
import pt.ubi.di.pdm.cardfolio.model.SortMode
import pt.ubi.di.pdm.cardfolio.model.StatsPurpose
import pt.ubi.di.pdm.cardfolio.model.StatusFilter
import pt.ubi.di.pdm.cardfolio.util.CardStats
import pt.ubi.di.pdm.cardfolio.util.CardStats.realizedProfit
import pt.ubi.di.pdm.cardfolio.util.CardStats.totalCost
import pt.ubi.di.pdm.cardfolio.util.FormatUtils

class CardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CardRepository(application)

    private fun <T> Flow<T>.toState(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), initial)

    // ---------- Data ----------
    val allCards: StateFlow<List<CardItem>> = repository.cards.toState(emptyList())
    val categories: StateFlow<List<CategoryCatalogItem>> = repository.categories.toState(emptyList())
    val collections: StateFlow<List<CollectionCatalogItem>> = repository.collections.toState(emptyList())
    val players: StateFlow<List<PlayerCatalogItem>> = repository.players.toState(emptyList())
    val clubs: StateFlow<List<ClubCatalogItem>> = repository.clubs.toState(emptyList())

    // ---------- Collection & resale screens ----------
    // Collection tabs: 0 -> Todas, 1 -> Coleção Pessoal, 2 -> Para Revenda
    private val _collectionTab = MutableStateFlow(0)
    val collectionTab: StateFlow<Int> = _collectionTab.asStateFlow()

    // Resale tabs: 0 -> Todas, 1 -> À venda, 2 -> Por anunciar, 3 -> Vendidas
    private val _resaleTab = MutableStateFlow(0)
    val resaleTab: StateFlow<Int> = _resaleTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow(ALL_CATEGORIES)
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow(StatusFilter.ALL)
    val selectedStatusFilter: StateFlow<StatusFilter> = _selectedStatusFilter.asStateFlow()

    private val _isGridView = MutableStateFlow(true)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    private val _sortMode = MutableStateFlow(SortMode.RECENT)
    val sortMode: StateFlow<SortMode> = _sortMode.asStateFlow()

    fun setCollectionTab(tab: Int) { _collectionTab.value = tab }
    fun setResaleTab(tab: Int) { _resaleTab.value = tab }
    fun setSearchQuery(query: String) { _searchQuery.value = query }
    fun setSelectedCategory(cat: String) { _selectedCategory.value = cat }
    fun setSelectedStatusFilter(filter: StatusFilter) { _selectedStatusFilter.value = filter }
    fun toggleViewMode() { _isGridView.value = !_isGridView.value }
    fun setSortMode(mode: SortMode) { _sortMode.value = mode }

    private fun CardItem.matchesQuery(query: String): Boolean {
        val q = query.trim()
        return q.isEmpty() || name.contains(q, ignoreCase = true) || edition.contains(q, ignoreCase = true)
    }

    val filteredCollectionCards: StateFlow<List<CardItem>> = combine(
        allCards, _collectionTab, _searchQuery, _selectedCategory,
        combine(_selectedStatusFilter, _sortMode, ::Pair)
    ) { cards, tab, query, category, (statusFilter, sort) ->
        val filtered = cards.filter { card ->
            val tabMatches = when (tab) {
                1 -> card.purpose == CardPurpose.PERSONAL
                2 -> card.purpose == CardPurpose.RESALE
                else -> true
            }
            tabMatches && card.matchesQuery(query) &&
                (category == ALL_CATEGORIES || card.category == category) &&
                statusFilter.matches(card)
        }
        sort.sort(filtered)
    }.toState(emptyList())

    val filteredResaleCards: StateFlow<List<CardItem>> = combine(allCards, _resaleTab, _searchQuery) { cards, tab, query ->
        cards.filter { card ->
            val tabMatches = when (tab) {
                1 -> card.status == CardStatus.LISTED
                2 -> card.status == CardStatus.KEPT
                3 -> card.status == CardStatus.SOLD
                else -> true
            }
            card.purpose == CardPurpose.RESALE && tabMatches && card.matchesQuery(query)
        }.sortedByDescending { it.date }
    }.toState(emptyList())

    val availableCategories: StateFlow<List<String>> = allCards.map { cards ->
        listOf(ALL_CATEGORIES) + cards.map { it.category }.distinct().sorted()
    }.toState(listOf(ALL_CATEGORIES))

    // ---------- KPIs ----------
    val personalCollection: StateFlow<List<CardItem>> = allCards.map { cards ->
        cards.filter { it.purpose == CardPurpose.PERSONAL }
    }.toState(emptyList())

    val personalInvestment: StateFlow<Double> = personalCollection.map { cards -> cards.sumOf { it.totalCost } }.toState(0.0)

    val collectionValue: StateFlow<Double> = personalCollection.map { cards -> cards.sumOf { it.value } }.toState(0.0)

    val resaleProfit: StateFlow<Double> = allCards.map { cards ->
        cards.filter { it.status == CardStatus.SOLD }.sumOf { it.realizedProfit }
    }.toState(0.0)

    private val resaleStock: Flow<List<CardItem>> = allCards.map { cards ->
        cards.filter { it.purpose == CardPurpose.RESALE && it.status != CardStatus.SOLD }
    }

    val resaleStockCount: StateFlow<Int> = resaleStock.map { it.size }.toState(0)

    val resaleStockInvestment: StateFlow<Double> = resaleStock.map { cards -> cards.sumOf { it.totalCost } }.toState(0.0)

    val resaleCompletedSalesCount: StateFlow<Int> = allCards.map { cards -> cards.count { it.status == CardStatus.SOLD } }.toState(0)

    val appreciationPercentage: StateFlow<Double> = combine(personalInvestment, collectionValue) { inv, value ->
        if (inv > 0) (value - inv) / inv * 100.0 else 0.0
    }.toState(0.0)

    val investmentCoveragePercentage: StateFlow<Double> = combine(personalInvestment, resaleProfit) { inv, profit ->
        if (inv > 0) profit / inv * 100.0 else 0.0
    }.toState(0.0)

    // ---------- Stats screen ----------
    private val _statsTab = MutableStateFlow(0) // 0: Coleção, 1: Finanças, 2: Evolução
    val statsTab: StateFlow<Int> = _statsTab.asStateFlow()

    private val _statsPurposeFilter = MutableStateFlow(StatsPurpose.PERSONAL)
    val statsPurposeFilter: StateFlow<StatsPurpose> = _statsPurposeFilter.asStateFlow()

    private val _statsCategoryFilter = MutableStateFlow(ALL_CATEGORIES)
    val statsCategoryFilter: StateFlow<String> = _statsCategoryFilter.asStateFlow()

    private val _statsSalesPeriod = MutableStateFlow(SalesPeriod.ALL)
    val statsSalesPeriod: StateFlow<SalesPeriod> = _statsSalesPeriod.asStateFlow()

    fun setStatsTab(tab: Int) { _statsTab.value = tab }
    fun setStatsPurposeFilter(purpose: StatsPurpose) { _statsPurposeFilter.value = purpose }
    fun setStatsCategoryFilter(category: String) { _statsCategoryFilter.value = category }
    fun setStatsSalesPeriod(period: SalesPeriod) { _statsSalesPeriod.value = period }

    val statsInventoryCards: StateFlow<List<CardItem>> = combine(
        allCards, _statsPurposeFilter, _statsCategoryFilter
    ) { cards, purpose, category ->
        cards.filter {
            it.status != CardStatus.SOLD && purpose.matches(it) && (category == ALL_CATEGORIES || it.category == category)
        }
    }.toState(emptyList())

    val soldCardsInPeriod: StateFlow<List<CardItem>> = combine(allCards, _statsSalesPeriod) { cards, period ->
        CardStats.soldInPeriod(cards, period)
    }.toState(emptyList())

    // ---------- Dialogs & sheets ----------
    private val _selectedCardForDetail = MutableStateFlow<CardItem?>(null)
    val selectedCardForDetail: StateFlow<CardItem?> = _selectedCardForDetail.asStateFlow()

    private val _isEditorOpen = MutableStateFlow(false)
    val isEditorOpen: StateFlow<Boolean> = _isEditorOpen.asStateFlow()

    private val _editorCardToEdit = MutableStateFlow<CardItem?>(null)
    val editorCardToEdit: StateFlow<CardItem?> = _editorCardToEdit.asStateFlow()

    private val _cardToDelete = MutableStateFlow<CardItem?>(null)
    val cardToDelete: StateFlow<CardItem?> = _cardToDelete.asStateFlow()

    private val _cardToRegisterSale = MutableStateFlow<CardItem?>(null)
    val cardToRegisterSale: StateFlow<CardItem?> = _cardToRegisterSale.asStateFlow()

    private val _cardToList = MutableStateFlow<CardItem?>(null)
    val cardToList: StateFlow<CardItem?> = _cardToList.asStateFlow()

    fun openCardDetail(card: CardItem) { _selectedCardForDetail.value = card }
    fun closeCardDetail() { _selectedCardForDetail.value = null }

    fun openNewCardEditor() {
        _editorCardToEdit.value = null
        _isEditorOpen.value = true
    }

    fun openEditCardEditor(card: CardItem) {
        _editorCardToEdit.value = card
        _isEditorOpen.value = true
    }

    fun closeCardEditor() {
        _isEditorOpen.value = false
        _editorCardToEdit.value = null
    }


    // ---------- Card actions ----------
    fun saveCard(card: CardItem) {
        viewModelScope.launch { repository.saveCard(card) }
        closeCardEditor()
        if (_selectedCardForDetail.value?.id == card.id) {
            _selectedCardForDetail.value = card
        }
    }

    fun promptDeleteCard(card: CardItem) { _cardToDelete.value = card }
    fun cancelDeleteCard() { _cardToDelete.value = null }
    fun confirmDeleteCard() {
        _cardToDelete.value?.let { card -> viewModelScope.launch { repository.deleteCard(card.id) } }
        _cardToDelete.value = null
        closeCardDetail()
    }

    fun promptRegisterSale(card: CardItem) { _cardToRegisterSale.value = card }
    fun cancelRegisterSale() { _cardToRegisterSale.value = null }
    fun confirmRegisterSale(salePrice: Double, saleDate: String) {
        _cardToRegisterSale.value?.let { card -> viewModelScope.launch { repository.registerSale(card.id, salePrice, saleDate) } }
        _cardToRegisterSale.value = null
        closeCardDetail()
    }

    fun promptListCard(card: CardItem) { _cardToList.value = card }
    fun cancelListCard() { _cardToList.value = null }
    fun confirmListCard(listPrice: Double) {
        _cardToList.value?.let { card -> viewModelScope.launch { repository.listCard(card.id, listPrice) } }
        _cardToList.value = null
        closeCardDetail()
    }

    /** Moves a personal card to resale and vice-versa. */
    fun togglePurpose(card: CardItem) {
        viewModelScope.launch {
            if (card.purpose == CardPurpose.PERSONAL) {
                repository.moveToResale(card.id)
            } else {
                if (card.status == CardStatus.SOLD) {
                    Toast.makeText(getApplication(), "Esta carta já foi vendida. Reverte a venda primeiro.", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                repository.moveToPersonal(card.id)
            }
        }
        closeCardDetail()
    }

    fun revertSale(card: CardItem) {
        viewModelScope.launch {
            repository.revertSale(card.id)
        }
        closeCardDetail()
    }

    // Reads the database directly: allCards may be empty when no screen is observing it
    suspend fun exportCsvData(): String = CardStats.toCsv(repository.cards.first())

    // ---------- Catalog ----------
    private val _catalogTab = MutableStateFlow(0) // 0: Categories, 1: Collections, 2: Players, 3: Clubs
    val catalogTab: StateFlow<Int> = _catalogTab.asStateFlow()

    fun setCatalogTab(tab: Int) { _catalogTab.value = tab }

    fun saveCatalogEntry(entry: CatalogEntry) = viewModelScope.launch { repository.saveCatalogEntry(entry) }

    fun toggleArchive(entry: CatalogEntry) = saveCatalogEntry(entry.toggledArchive())

    /** [onResult] receives false when the entry is still in use and was not deleted. */
    fun deleteCatalogEntry(entry: CatalogEntry, onResult: (Boolean) -> Unit) =
        viewModelScope.launch { onResult(repository.deleteCatalogEntry(entry)) }

    // ---------- User, session & settings ----------
    private val _userName = MutableStateFlow("")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _userEmail = MutableStateFlow("")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _userPhotoUri = MutableStateFlow<String?>(null)
    val userPhotoUri: StateFlow<String?> = _userPhotoUri.asStateFlow()

    private val _hideCurrencyValues = MutableStateFlow(repository.hideCurrencyValues)
    val hideCurrencyValues: StateFlow<Boolean> = _hideCurrencyValues.asStateFlow()

    private val _isDarkMode = MutableStateFlow(repository.isDarkMode)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Read once at startup to pick the first screen
    val isLoggedIn: Boolean = repository.hasSavedSession

    // True when the saved session no longer matches a user (e.g. database was wiped): UI goes back to login
    private val _sessionLost = MutableStateFlow(false)
    val sessionLost: StateFlow<Boolean> = _sessionLost.asStateFlow()

    init {
        FormatUtils.hideCurrencyValues = _hideCurrencyValues.value
        if (isLoggedIn) {
            viewModelScope.launch {
                val user = repository.getUser(repository.currentUserId.value)
                if (user != null) showUser(user) else {
                    repository.logout()
                    _sessionLost.value = true
                }
            }
        }
    }

    private fun showUser(user: UserEntity) {
        _userName.value = user.name
        _userEmail.value = user.email
        _userPhotoUri.value = user.photoUri
    }

    fun login(email: String, pass: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val user = repository.login(email, pass)
            if (user != null) {
                showUser(user)
                onSuccess()
            } else {
                onError("Email ou palavra-passe incorretos.")
            }
        }
    }

    fun register(name: String, email: String, pass: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        if (name.isBlank() || email.isBlank() || pass.isBlank()) {
            onError("Preenche todos os campos.")
            return
        }
        viewModelScope.launch {
            val user = repository.register(name, email, pass)
            if (user != null) {
                showUser(user)
                onSuccess()
            } else {
                onError("Este email já está registado.")
            }
        }
    }

    fun logout() {
        repository.logout()
        _sessionLost.value = false
        closeCardDetail()
        closeCardEditor()
    }

    /** Deletes the account and all its data, then calls [onDone] (which logs out and navigates). */
    fun deleteAccount(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.deleteAccount()
            onDone()
        }
    }

    fun updateProfile(name: String, photoUri: String?) {
        if (name.isBlank()) return
        _userName.value = name.trim()
        _userPhotoUri.value = photoUri
        viewModelScope.launch { repository.updateProfile(repository.currentUserId.value, name, photoUri) }
    }

    fun changePassword(currentPass: String, newPass: String, onResult: (success: Boolean, message: String) -> Unit) {
        if (newPass.isBlank()) {
            onResult(false, "A nova palavra-passe não pode estar vazia.")
            return
        }
        viewModelScope.launch {
            val ok = repository.updatePassword(repository.currentUserId.value, currentPass, newPass)
            onResult(ok, if (ok) "Palavra-passe alterada com sucesso!" else "Palavra-passe atual incorreta.")
        }
    }

    fun toggleDarkMode() {
        val next = !_isDarkMode.value
        _isDarkMode.value = next
        repository.setDarkMode(next)
    }

    fun setHideCurrencyValues(hide: Boolean) {
        _hideCurrencyValues.value = hide
        FormatUtils.hideCurrencyValues = hide
        repository.setHideCurrencyValues(hide)
    }
}
