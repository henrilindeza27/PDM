package pt.ubi.di.pdm.cardfolio.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import pt.ubi.di.pdm.cardfolio.ui.components.CardDetailModalBottomSheet
import pt.ubi.di.pdm.cardfolio.ui.components.CardFormModalBottomSheet
import pt.ubi.di.pdm.cardfolio.ui.components.CardfolioHeader
import pt.ubi.di.pdm.cardfolio.ui.components.DeleteConfirmDialog
import pt.ubi.di.pdm.cardfolio.ui.components.ListCardDialog
import pt.ubi.di.pdm.cardfolio.ui.components.RegisterSaleDialog
import pt.ubi.di.pdm.cardfolio.ui.screens.CatalogManagementScreen
import pt.ubi.di.pdm.cardfolio.ui.screens.CollectionScreen
import pt.ubi.di.pdm.cardfolio.ui.screens.DashboardScreen
import pt.ubi.di.pdm.cardfolio.ui.screens.LoginScreen
import pt.ubi.di.pdm.cardfolio.ui.screens.ProfileSettingsScreen
import pt.ubi.di.pdm.cardfolio.ui.screens.RegisterScreen
import pt.ubi.di.pdm.cardfolio.ui.screens.ResaleScreen
import pt.ubi.di.pdm.cardfolio.ui.screens.StatsScreen
import pt.ubi.di.pdm.cardfolio.ui.theme.OffWhiteBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Login : Screen("login", "Login", Icons.Outlined.Dashboard)
    object Register : Screen("register", "Registo", Icons.Outlined.Dashboard)
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Outlined.Dashboard)
    object Collection : Screen("collection", "Coleção", Icons.Outlined.Layers)
    object Resale : Screen("resale", "Revenda", Icons.Outlined.SwapHoriz)
    object Stats : Screen("stats", "Estatísticas", Icons.Outlined.Analytics)
    object Profile : Screen("profile", "Perfil", Icons.Outlined.Person)
    object CatalogManagement : Screen("catalog_management", "Gerir catálogo", Icons.Outlined.Folder)
}

val items = listOf(
    Screen.Dashboard,
    Screen.Collection,
    Screen.Resale,
    Screen.Stats,
)

@Composable
fun CardfolioApp(
    viewModel: CardViewModel = viewModel()
) {
    val navController = rememberNavController()
    val sessionLost by viewModel.sessionLost.collectAsState()

    LaunchedEffect(sessionLost) {
        if (sessionLost) {
            viewModel.logout()
            navController.navigate(Screen.Login.route) { popUpTo(0) { inclusive = true } }
        }
    }
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Login.route

    val configuration = LocalConfiguration.current
    val isTabletOrLandscape = configuration.screenWidthDp > 600

    val currentScreen = items.find { it.route == currentRoute } ?: Screen.Dashboard
    val showBars = currentRoute in items.map { it.route } || currentRoute == Screen.Profile.route || currentRoute == Screen.CatalogManagement.route

    // State bindings
    val selectedCardForDetail by viewModel.selectedCardForDetail.collectAsState()
    val isEditorOpen by viewModel.isEditorOpen.collectAsState()
    val editorCardToEdit by viewModel.editorCardToEdit.collectAsState()
    val cardToDelete by viewModel.cardToDelete.collectAsState()
    val cardToRegisterSale by viewModel.cardToRegisterSale.collectAsState()
    val cardToList by viewModel.cardToList.collectAsState()

    Scaffold(
        topBar = {
            if (showBars) {
                CardfolioHeader(
                    viewModel = viewModel,
                    onProfileClick = {
                        if (currentRoute != Screen.Profile.route) {
                            navController.navigate(Screen.Profile.route) {
                                launchSingleTop = true
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (showBars && !isTabletOrLandscape) {
                NavigationBar(
                    containerColor = SurfaceWhite,
                    contentColor = PrimaryIndigo
                ) {
                    items.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title, fontSize = 11.sp) },
                            selected = selected,
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryIndigo,
                                selectedTextColor = PrimaryIndigo,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted,
                                indicatorColor = SurfaceWhite
                            ),
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        },
        containerColor = OffWhiteBackground
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (showBars && isTabletOrLandscape) {
                NavigationRail(
                    containerColor = SurfaceWhite,
                    contentColor = PrimaryIndigo
                ) {
                    items.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationRailItem(
                            icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title, fontSize = 11.sp) },
                            selected = selected,
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = PrimaryIndigo,
                                selectedTextColor = PrimaryIndigo,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted,
                                indicatorColor = SurfaceWhite
                            ),
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                NavHost(
                    navController = navController,
                    startDestination = if (viewModel.isLoggedIn) Screen.Dashboard.route else Screen.Login.route
                ) {
                    composable(Screen.Login.route) {
                        LoginScreen(
                            viewModel = viewModel,
                            onLoginSuccess = {
                                navController.navigate(Screen.Dashboard.route) {
                                    popUpTo(Screen.Login.route) { inclusive = true }
                                }
                            },
                            onNavigateToRegister = {
                                navController.navigate(Screen.Register.route)
                            }
                        )
                    }

                    composable(Screen.Register.route) {
                        RegisterScreen(
                            viewModel = viewModel,
                            onRegisterSuccess = {
                                navController.navigate(Screen.Dashboard.route) {
                                    popUpTo(Screen.Login.route) { inclusive = true }
                                }
                            },
                            onNavigateToLogin = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.Dashboard.route) {
                        DashboardScreen(
                            viewModel = viewModel,
                            onNavigateToCollection = {
                                navController.navigate(Screen.Collection.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onNavigateToResale = {
                                navController.navigate(Screen.Resale.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onNavigateToStats = {
                                navController.navigate(Screen.Stats.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }

                    composable(Screen.Collection.route) {
                        CollectionScreen(viewModel = viewModel)
                    }

                    composable(Screen.Resale.route) {
                        ResaleScreen(viewModel = viewModel)
                    }

                    composable(Screen.Stats.route) {
                        StatsScreen(viewModel = viewModel)
                    }

                    composable(Screen.Profile.route) {
                        ProfileSettingsScreen(
                            viewModel = viewModel,
                            onBackClick = { navController.popBackStack() },
                            onNavigateToCatalog = {
                                navController.navigate(Screen.CatalogManagement.route) {
                                    launchSingleTop = true
                                }
                            },
                            onLogout = {
                                viewModel.logout()
                                navController.navigate(Screen.Login.route) {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(Screen.CatalogManagement.route) {
                        CatalogManagementScreen(
                            viewModel = viewModel,
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    // Modal Bottom Sheets & Dialogs
    selectedCardForDetail?.let { card ->
        CardDetailModalBottomSheet(
            card = card,
            onDismiss = { viewModel.closeCardDetail() },
            onEditClick = { viewModel.openEditCardEditor(card) },
            onTogglePurposeClick = { viewModel.togglePurpose(card) },
            onListCardClick = { viewModel.promptListCard(card) },
            onRegisterSaleClick = { viewModel.promptRegisterSale(card) },
            onRevertSaleClick = { viewModel.revertSale(card) },
            onDeleteClick = { viewModel.promptDeleteCard(card) }
        )
    }

    if (isEditorOpen) {
        val categories by viewModel.categories.collectAsState()
        val collections by viewModel.collections.collectAsState()
        val players by viewModel.players.collectAsState()
        val clubs by viewModel.clubs.collectAsState()

        CardFormModalBottomSheet(
            cardToEdit = editorCardToEdit,
            categories = categories,
            collections = collections,
            players = players,
            clubs = clubs,
            onDismiss = { viewModel.closeCardEditor() },
            onSave = { updatedCard -> viewModel.saveCard(updatedCard) },
            onAddCatalogEntry = viewModel::saveCatalogEntry
        )
    }

    cardToDelete?.let { card ->
        DeleteConfirmDialog(
            card = card,
            onConfirm = { viewModel.confirmDeleteCard() },
            onDismiss = { viewModel.cancelDeleteCard() }
        )
    }

    cardToRegisterSale?.let { card ->
        RegisterSaleDialog(
            card = card,
            onConfirm = { salePrice, saleDate -> viewModel.confirmRegisterSale(salePrice, saleDate) },
            onDismiss = { viewModel.cancelRegisterSale() }
        )
    }

    cardToList?.let { card ->
        ListCardDialog(
            card = card,
            onConfirm = { listPrice -> viewModel.confirmListCard(listPrice) },
            onDismiss = { viewModel.cancelListCard() }
        )
    }
}
