package pt.ubi.di.pdm.cardfolio.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.automirrored.outlined.TrendingDown
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.SalesPeriod
import pt.ubi.di.pdm.cardfolio.ui.components.CardThumbnail
import pt.ubi.di.pdm.cardfolio.ui.components.SectionCard
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.InfoBlue
import pt.ubi.di.pdm.cardfolio.ui.theme.InfoBlueSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRed
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRedSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.MedalGold
import pt.ubi.di.pdm.cardfolio.ui.theme.MedalSilver
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreen
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreenSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmberSoft
import pt.ubi.di.pdm.cardfolio.util.CardStats.realizedProfit
import pt.ubi.di.pdm.cardfolio.util.CardStats.totalCost
import pt.ubi.di.pdm.cardfolio.util.FormatUtils
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel
import kotlin.math.abs

/**
 * Finance tab of the stats screen, top to bottom:
 * realized profit (hero) -> where the money is (collection vs resale stock) -> sales in a period -> best sales.
 */
@Composable
internal fun FinanceTab(viewModel: CardViewModel) {
    val resaleProfit by viewModel.resaleProfit.collectAsState()
    val completedSales by viewModel.resaleCompletedSalesCount.collectAsState()
    val coverage by viewModel.investmentCoveragePercentage.collectAsState()
    val personalInvestment by viewModel.personalInvestment.collectAsState()
    val collectionValue by viewModel.collectionValue.collectAsState()
    val appreciation by viewModel.appreciationPercentage.collectAsState()
    val stockCount by viewModel.resaleStockCount.collectAsState()
    val stockInvestment by viewModel.resaleStockInvestment.collectAsState()
    val salesPeriod by viewModel.statsSalesPeriod.collectAsState()
    val soldCards by viewModel.soldCardsInPeriod.collectAsState()

    ProfitHeroCard(profit = resaleProfit, completedSales = completedSales, coverage = coverage)

    Row(
        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        MetricTile(
            title = "Coleção pessoal",
            icon = Icons.Outlined.Savings,
            iconTint = InfoBlue,
            iconBackground = InfoBlueSoft,
            value = FormatUtils.formatCurrency(collectionValue),
            caption = "Valor estimado",
            detail = "${FormatUtils.formatCurrency(personalInvestment)} investidos",
            badge = if (personalInvestment > 0) FormatUtils.formatPercent(appreciation, true) else null,
            badgePositive = appreciation >= 0,
            modifier = Modifier.weight(1f).fillMaxHeight()
        )
        MetricTile(
            title = "Stock de revenda",
            icon = Icons.Outlined.Inventory2,
            iconTint = WarningAmber,
            iconBackground = WarningAmberSoft,
            value = "$stockCount ${if (stockCount == 1) "carta" else "cartas"}",
            caption = "Por vender",
            detail = "${FormatUtils.formatCurrency(stockInvestment)} investidos",
            modifier = Modifier.weight(1f).fillMaxHeight()
        )
    }

    SalesSection(
        period = salesPeriod,
        onPeriodChange = viewModel::setStatsSalesPeriod,
        soldCards = soldCards
    )

    BestSalesSection(soldCards = soldCards, onCardClick = viewModel::openCardDetail)
}

/** Big coloured card with the realized resale profit and how much of the collection it pays for. */
@Composable
private fun ProfitHeroCard(profit: Double, completedSales: Int, coverage: Double) {
    val background = if (profit < 0) LossRed else PrimaryIndigo
    val faded = Color.White.copy(alpha = 0.75f)

    Surface(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)),
        color = background
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (profit < 0) Icons.AutoMirrored.Outlined.TrendingDown else Icons.AutoMirrored.Outlined.TrendingUp,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Lucro realizado com revendas", fontSize = 13.sp, color = faded, fontWeight = FontWeight.Medium)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = FormatUtils.formatCurrency(profit, includePlusSign = true),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = when (completedSales) {
                    0 -> "Ainda sem vendas concluídas"
                    1 -> "Em 1 venda concluída"
                    else -> "Em $completedSales vendas concluídas"
                },
                fontSize = 12.sp,
                color = faded
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Cobre o investimento da coleção", fontSize = 12.sp, color = faded)
                Text(FormatUtils.formatPercent(coverage.coerceAtLeast(0.0)), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((coverage / 100.0).coerceIn(0.0, 1.0).toFloat())
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                )
            }
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    icon: ImageVector,
    iconTint: Color,
    iconBackground: Color,
    value: String,
    caption: String,
    detail: String,
    modifier: Modifier = Modifier,
    badge: String? = null,
    badgePositive: Boolean = true
) {
    val shape = RoundedCornerShape(16.dp)
    Surface(
        modifier = modifier.clip(shape).border(1.dp, BorderSubtle, shape),
        color = SurfaceWhite
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(28.dp).clip(CircleShape).background(iconBackground),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(15.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(caption, fontSize = 11.sp, color = TextMuted)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
            Spacer(modifier = Modifier.height(4.dp))
            Text(detail, fontSize = 11.sp, color = TextSecondary)
            if (badge != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "$badge valorização",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (badgePositive) SuccessGreen else LossRed,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (badgePositive) SuccessGreenSoft else LossRedSoft)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

/** Sales in the chosen period: chips to pick it, key numbers and a revenue = cost + profit bar. */
@Composable
private fun SalesSection(period: SalesPeriod, onPeriodChange: (SalesPeriod) -> Unit, soldCards: List<CardItem>) {
    val revenue = soldCards.sumOf { it.salePrice ?: it.value }
    val cost = soldCards.sumOf { it.totalCost }
    val result = revenue - cost

    SectionCard(title = "Vendas", subtitle = "Escolhe o período a analisar") {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SalesPeriod.entries.forEach { option ->
                FilterChip(
                    selected = option == period,
                    onClick = { onPeriodChange(option) },
                    label = { Text(option.label, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryIndigoSoft,
                        selectedLabelColor = PrimaryIndigo
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (soldCards.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(TagBackground).padding(vertical = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.AutoMirrored.Outlined.ReceiptLong, contentDescription = null, tint = TextMuted, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Sem vendas neste período", fontSize = 12.sp, color = TextSecondary)
                }
            }
            return@SectionCard
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            KeyNumber("Vendidas", "${soldCards.size}")
            KeyNumber("Receita", FormatUtils.formatCurrency(revenue))
            // Same "retorno" (profit / cost) as in the ranking below, so the two never disagree
            KeyNumber(
                "Retorno",
                if (cost > 0) FormatUtils.formatPercent(result / cost * 100, true) else "—",
                color = if (result < 0) LossRed else SuccessGreen
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Revenue split into what the cards cost and what was earned
        val costShare = if (revenue > 0) (cost / revenue).coerceIn(0.0, 1.0).toFloat() else 1f
        Row(modifier = Modifier.fillMaxWidth().height(12.dp).clip(CircleShape).background(TagBackground)) {
            if (costShare > 0f) Box(modifier = Modifier.weight(costShare).fillMaxHeight().background(MedalSilver))
            if (costShare < 1f) Box(modifier = Modifier.weight(1f - costShare).fillMaxHeight().background(SuccessGreen))
        }

        Spacer(modifier = Modifier.height(12.dp))

        BreakdownRow(MedalSilver, "Custo das cartas vendidas", FormatUtils.formatCurrency(cost))
        val resultColor = if (result < 0) LossRed else SuccessGreen
        BreakdownRow(
            dotColor = resultColor,
            label = if (result < 0) "Prejuízo" else "Lucro",
            value = FormatUtils.formatCurrency(result, true),
            valueColor = resultColor,
            bold = true
        )
    }
}

@Composable
private fun KeyNumber(label: String, value: String, color: Color = TextPrimary) {
    Column {
        Text(label, fontSize = 11.sp, color = TextMuted)
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun BreakdownRow(
    dotColor: Color,
    label: String,
    value: String,
    valueColor: Color = TextPrimary,
    bold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(dotColor))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            label,
            fontSize = 13.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            color = if (bold) TextPrimary else TextSecondary,
            modifier = Modifier.weight(1f)
        )
        Text(value, fontSize = 13.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold, color = valueColor)
    }
}

/**
 * Top 5 sales of the period by realized profit. The best one gets a featured card;
 * every entry opens the card details when tapped. Profit bars grow in on first show.
 */
@Composable
private fun BestSalesSection(soldCards: List<CardItem>, onCardClick: (CardItem) -> Unit) {
    if (soldCards.isEmpty()) return
    val ranked = remember(soldCards) { soldCards.sortedByDescending { it.realizedProfit }.take(5) }
    val maxAbsProfit = remember(ranked) { ranked.maxOf { abs(it.realizedProfit) }.takeIf { it > 0 } ?: 1.0 }

    SectionCard(title = "Vendas mais rentáveis", subtitle = "Toca numa venda para ver a carta") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FeaturedSale(card = ranked.first(), onClick = { onCardClick(ranked.first()) })
            ranked.drop(1).forEachIndexed { index, card ->
                SaleRow(
                    rank = index + 2,
                    card = card,
                    barFraction = (abs(card.realizedProfit) / maxAbsProfit).toFloat(),
                    animationDelay = 100 * (index + 1),
                    onClick = { onCardClick(card) }
                )
            }
        }
    }
}

/** Return on the money spent on the card, in % ("—" when it cost nothing). */
private fun CardItem.returnPercent(): String =
    if (totalCost > 0) FormatUtils.formatPercent(realizedProfit / totalCost * 100, true) else "—"

@Composable
private fun FeaturedSale(card: CardItem, onClick: () -> Unit) {
    val profit = card.realizedProfit
    val accent = if (profit < 0) LossRed else MedalGold
    val shape = RoundedCornerShape(16.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.16f), accent.copy(alpha = 0.03f))))
            .border(1.dp, accent.copy(alpha = 0.4f), shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            CardThumbnail(card = card, size = 64.dp, borderColor = accent)
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (-6).dp, y = (-6).dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Outlined.EmojiEvents, contentDescription = "1.º lugar", tint = Color.White, modifier = Modifier.size(14.dp))
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("Melhor venda", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = accent)
            Text(card.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${FormatUtils.formatCurrency(card.totalCost)} → ${FormatUtils.formatCurrency(card.salePrice ?: card.value)}",
                fontSize = 12.sp,
                color = TextSecondary
            )
            Text(FormatUtils.formatDateShort(card.saleDate), fontSize = 11.sp, color = TextMuted)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                FormatUtils.formatCurrency(profit, true),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (profit < 0) LossRed else SuccessGreen
            )
            Text("${card.returnPercent()} retorno", fontSize = 11.sp, color = TextSecondary)
        }
        Icon(imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
    }
}

@Composable
private fun SaleRow(rank: Int, card: CardItem, barFraction: Float, animationDelay: Int, onClick: () -> Unit) {
    val profit = card.realizedProfit
    val color = if (profit < 0) LossRed else SuccessGreen
    val bar = remember { Animatable(0f) }
    LaunchedEffect(barFraction) {
        bar.animateTo(barFraction.coerceIn(0.03f, 1f), tween(durationMillis = 700, delayMillis = animationDelay))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$rank", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextMuted, modifier = Modifier.width(18.dp))
        CardThumbnail(card = card, size = 40.dp)
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    card.name,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(FormatUtils.formatCurrency(profit, true), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            }
            Spacer(modifier = Modifier.height(5.dp))
            Box(modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(TagBackground)) {
                Box(modifier = Modifier.fillMaxWidth(bar.value).height(6.dp).clip(CircleShape).background(color))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Vendida por ${FormatUtils.formatCurrency(card.salePrice ?: card.value)} · ${card.returnPercent()} retorno",
                fontSize = 11.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
    }
}
