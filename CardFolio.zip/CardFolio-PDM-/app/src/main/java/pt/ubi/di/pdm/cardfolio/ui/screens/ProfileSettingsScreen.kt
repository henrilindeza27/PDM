package pt.ubi.di.pdm.cardfolio.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ExitToApp
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.ubi.di.pdm.cardfolio.model.SortMode
import pt.ubi.di.pdm.cardfolio.ui.components.ResponsiveContainer
import pt.ubi.di.pdm.cardfolio.ui.components.rememberCsvExporter
import pt.ubi.di.pdm.cardfolio.util.ImageStorage
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsScreen(
    viewModel: CardViewModel,
    onBackClick: () -> Unit,
    onNavigateToCatalog: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val exportCsv = rememberCsvExporter(viewModel)
    val scope = rememberCoroutineScope()
    val userName by viewModel.userName.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()
    val userPhotoUri by viewModel.userPhotoUri.collectAsState()
    val hideCurrencyValues by viewModel.hideCurrencyValues.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()

    val collectionTab by viewModel.collectionTab.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()
    val isGridView by viewModel.isGridView.collectAsState()

    var isEditProfileOpen by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showSortDialog by remember { mutableStateOf(false) }
    var showInitialViewDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                ImageStorage.copyToAppStorage(context, it)?.let { saved -> viewModel.updateProfile(userName, saved) }
                    ?: Toast.makeText(context, "Não foi possível carregar a imagem.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    ResponsiveContainer(modifier = modifier) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 32.dp)
    ) {
        // Top Header Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SurfaceWhite
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = "Voltar",
                        tint = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Perfil e Definições",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. PROFILE HEADER CARD
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp)),
                color = SurfaceWhite
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(PrimaryIndigoSoft)
                            .border(1.dp, PrimaryIndigo.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!userPhotoUri.isNullOrEmpty()) {
                            AsyncImage(
                                model = userPhotoUri,
                                contentDescription = "Foto de perfil",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.matchParentSize()
                            )
                        } else {
                            Text(
                                text = userName.take(2).uppercase().ifBlank { "?" },
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryIndigo
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = userEmail,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    OutlinedButton(
                        onClick = { isEditProfileOpen = true },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(imageVector = Icons.Outlined.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Editar", fontSize = 11.sp)
                    }
                }
            }

            // 2. SECÇÃO "CONTA"
            SettingsGroup(title = "CONTA") {
                SettingItemRow(
                    icon = Icons.Outlined.Person,
                    title = "Dados pessoais",
                    subtitle = "Nome e fotografia de perfil",
                    onClick = { isEditProfileOpen = true }
                )
                SettingItemRow(
                    icon = Icons.Outlined.Folder,
                    title = "Gerir catálogo",
                    subtitle = "Organiza as coleções, jogadores e clubes das tuas cartas.",
                    onClick = onNavigateToCatalog
                )
                SettingItemRow(
                    icon = Icons.Outlined.Lock,
                    title = "Alterar palavra-passe",
                    subtitle = "Segurança da conta",
                    onClick = { showPasswordDialog = true }
                )
            }

            // 3. SECÇÃO "PREFERÊNCIAS"
            SettingsGroup(title = "PREFERÊNCIAS") {
                SettingValueRow(
                    icon = Icons.Outlined.Settings,
                    title = "Vista das cartas",
                    value = if (isGridView) "Grelha" else "Lista",
                    onClick = { viewModel.toggleViewMode() }
                )
                SettingValueRow(
                    icon = Icons.Outlined.Settings,
                    title = "Ordenação predefinida",
                    value = sortMode.label,
                    onClick = { showSortDialog = true }
                )
                SettingValueRow(
                    icon = Icons.Outlined.Settings,
                    title = "Vista inicial da coleção",
                    value = when (collectionTab) {
                        1 -> "Coleção pessoal"
                        2 -> "Para revenda"
                        else -> "Todas as cartas"
                    },
                    onClick = { showInitialViewDialog = true }
                )
                SettingSwitchRow(
                    icon = Icons.Outlined.DarkMode,
                    title = "Modo escuro",
                    subtitle = "Alternar entre tema claro e escuro",
                    checked = isDarkMode,
                    onCheckedChange = { viewModel.toggleDarkMode() }
                )
                SettingSwitchRow(
                    icon = Icons.Outlined.Settings,
                    title = "Ocultar valores monetários",
                    subtitle = "Substitui preços por ••••",
                    checked = hideCurrencyValues,
                    onCheckedChange = { viewModel.setHideCurrencyValues(it) }
                )
            }

            // 4. SECÇÃO "DADOS"
            SettingsGroup(title = "DADOS") {
                SettingItemRow(
                    icon = Icons.Outlined.Folder,
                    title = "Exportar dados em CSV",
                    subtitle = "Exporta os teus registos para uma folha de cálculo",
                    onClick = {
                        exportCsv()
                    }
                )
            }

            // 5. SECÇÃO "SOBRE"
            SettingsGroup(title = "SOBRE") {
                SettingItemRow(
                    icon = Icons.Outlined.Info,
                    title = "Sobre o Cardfolio",
                    subtitle = "Versão 1.0.0 · Gestão profissional de coleções",
                    onClick = { showAboutDialog = true }
                )
            }

            // 6. SECÇÃO "SESSÃO"
            SettingsGroup(title = "SESSÃO") {
                SettingItemRow(
                    icon = Icons.AutoMirrored.Outlined.ExitToApp,
                    title = "Terminar sessão",
                    subtitle = "Sai da tua conta atual",
                    onClick = onLogout,
                    isDestructive = true
                )
                SettingItemRow(
                    icon = Icons.Outlined.Delete,
                    title = "Eliminar conta",
                    subtitle = "Remove permanentemente os teus dados",
                    onClick = { showDeleteAccountDialog = true },
                    isDestructive = true
                )
            }
        }
    }

    // EDIT PROFILE BOTTOM SHEET
    if (isEditProfileOpen) {
        var editName by remember { mutableStateOf(userName) }
        ModalBottomSheet(
            onDismissRequest = { isEditProfileOpen = false },
            containerColor = SurfaceWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Editar Dados Pessoais",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                OutlinedTextField(
                    value = editName,
                    onValueChange = { editName = it },
                    label = { Text("Nome de colecionador") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedButton(
                    onClick = { photoPickerLauncher.launch(arrayOf("image/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Alterar fotografia de perfil")
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(onClick = { isEditProfileOpen = false }, modifier = Modifier.weight(1f)) {
                        Text("Cancelar")
                    }
                    Button(
                        onClick = {
                            viewModel.updateProfile(editName, userPhotoUri)
                            isEditProfileOpen = false
                            Toast.makeText(context, "Perfil atualizado!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                    ) {
                        Text("Guardar", color = Color.White)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // PASSWORD DIALOG
    if (showPasswordDialog) {
        var currentPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPasswordDialog = false },
            title = { Text("Alterar Palavra-passe") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = currentPass, onValueChange = { currentPass = it }, label = { Text("Palavra-passe atual") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    OutlinedTextField(value = newPass, onValueChange = { newPass = it }, label = { Text("Nova palavra-passe") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.changePassword(currentPass, newPass) { success, message ->
                            if (success) showPasswordDialog = false
                            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                ) {
                    Text("Confirmar", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showPasswordDialog = false }) { Text("Cancelar") }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    // DELETE ACCOUNT DIALOG
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountDialog = false },
            title = { Text("Eliminar Conta") },
            text = { Text("Tens a certeza que pretendes eliminar permanentemente a tua conta e todos os dados associados?") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountDialog = false
                        viewModel.deleteAccount(onDone = onLogout)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("Eliminar", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteAccountDialog = false }) { Text("Cancelar") }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    // ABOUT DIALOG
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("Sobre o Cardfolio") },
            text = { Text("Cardfolio é a aplicação definitiva para colecionadores e investidores de cartas e cromos. Organiza o teu catálogo, monitoriza o teu portefólio e analisa o teu lucro em tempo real.") },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)) {
                    Text("Fechar", color = Color.White)
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    // SORT DIALOG
    if (showSortDialog) {
        AlertDialog(
            onDismissRequest = { showSortDialog = false },
            title = { Text("Ordenação predefinida") },
            text = {
                Column {
                    SortMode.entries.forEach { opt ->
                        TextButton(
                            onClick = {
                                viewModel.setSortMode(opt)
                                showSortDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(opt.label, color = if (sortMode == opt) PrimaryIndigo else TextPrimary)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { OutlinedButton(onClick = { showSortDialog = false }) { Text("Cancelar") } },
            shape = RoundedCornerShape(16.dp)
        )
    }

    // INITIAL VIEW DIALOG
    if (showInitialViewDialog) {
        AlertDialog(
            onDismissRequest = { showInitialViewDialog = false },
            title = { Text("Vista inicial da coleção") },
            text = {
                Column {
                    listOf(0 to "Todas as cartas", 1 to "Coleção pessoal", 2 to "Para revenda").forEach { (tab, label) ->
                        TextButton(
                            onClick = {
                                viewModel.setCollectionTab(tab)
                                showInitialViewDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(label, color = if (collectionTab == tab) PrimaryIndigo else TextPrimary)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { OutlinedButton(onClick = { showInitialViewDialog = false }) { Text("Cancelar") } },
            shape = RoundedCornerShape(16.dp)
        )
    }
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary,
            modifier = Modifier.padding(start = 4.dp)
        )
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp)),
            color = SurfaceWhite
        ) {
            Column(modifier = Modifier.fillMaxWidth(), content = content)
        }
    }
}

@Composable
private fun SettingItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    isDestructive: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isDestructive) Color.Red else PrimaryIndigo,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDestructive) Color.Red else TextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
        Icon(
            imageVector = Icons.Outlined.ChevronRight,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun SettingValueRow(
    icon: ImageVector,
    title: String,
    value: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = PrimaryIndigo,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            fontSize = 12.sp,
            color = TextSecondary,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            imageVector = Icons.Outlined.ChevronRight,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = PrimaryIndigo,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
