package pt.ubi.di.pdm.cardfolio.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Insert
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity): Int

    // Foreign keys cascade: removes all the user's cards and catalog too
    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUser(id: String)
}

@Dao
interface CardDao {
    @Query(
        """
        SELECT cards.*, categories.name AS categoryName,
               collections.name AS collectionName, collections.season AS collectionSeason
        FROM cards
        INNER JOIN categories ON categories.id = cards.categoryId
        LEFT JOIN collections ON collections.id = cards.collectionId
        WHERE cards.userId = :userId
        """
    )
    fun getCardsForUser(userId: String): Flow<List<CardWithNames>>

    @Query("SELECT * FROM cards WHERE id = :cardId LIMIT 1")
    suspend fun getCardById(cardId: String): CardEntity?

    @Upsert
    suspend fun upsertCard(card: CardEntity)

    @Query("DELETE FROM cards WHERE id = :cardId")
    suspend fun deleteCard(cardId: String)

    @Query("SELECT COUNT(*) FROM cards WHERE collectionId = :collectionId")
    suspend fun countByCollection(collectionId: String): Int

    @Query("SELECT COUNT(*) FROM cards WHERE playerId = :playerId")
    suspend fun countByPlayer(playerId: String): Int

    @Query("SELECT COUNT(*) FROM cards WHERE clubId = :clubId")
    suspend fun countByClub(clubId: String): Int
}

@Dao
interface CatalogDao {
    @Query("SELECT * FROM categories WHERE userId = :userId ORDER BY name")
    fun getCategoriesForUser(userId: String): Flow<List<CategoryEntity>>

    @Upsert
    suspend fun upsertCategory(category: CategoryEntity)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteCategory(id: String)

    @Query(
        """
        SELECT (SELECT COUNT(*) FROM cards WHERE categoryId = :categoryId)
             + (SELECT COUNT(*) FROM collections WHERE categoryId = :categoryId)
             + (SELECT COUNT(*) FROM players WHERE categoryId = :categoryId)
             + (SELECT COUNT(*) FROM clubs WHERE categoryId = :categoryId)
        """
    )
    suspend fun countCategoryUsage(categoryId: String): Int

    @Query(
        """
        SELECT collections.*, categories.name AS categoryName FROM collections
        INNER JOIN categories ON categories.id = collections.categoryId
        WHERE collections.userId = :userId ORDER BY collections.name
        """
    )
    fun getCollectionsForUser(userId: String): Flow<List<CollectionWithCategory>>

    @Upsert
    suspend fun upsertCollection(collection: CollectionEntity)

    @Query("DELETE FROM collections WHERE id = :id")
    suspend fun deleteCollection(id: String)

    @Query(
        """
        SELECT players.*, categories.name AS categoryName FROM players
        INNER JOIN categories ON categories.id = players.categoryId
        WHERE players.userId = :userId ORDER BY players.name
        """
    )
    fun getPlayersForUser(userId: String): Flow<List<PlayerWithCategory>>

    @Upsert
    suspend fun upsertPlayer(player: PlayerEntity)

    @Query("DELETE FROM players WHERE id = :id")
    suspend fun deletePlayer(id: String)

    @Query(
        """
        SELECT clubs.*, categories.name AS categoryName FROM clubs
        INNER JOIN categories ON categories.id = clubs.categoryId
        WHERE clubs.userId = :userId ORDER BY clubs.name
        """
    )
    fun getClubsForUser(userId: String): Flow<List<ClubWithCategory>>

    @Upsert
    suspend fun upsertClub(club: ClubEntity)

    @Query("DELETE FROM clubs WHERE id = :id")
    suspend fun deleteClub(id: String)
}
