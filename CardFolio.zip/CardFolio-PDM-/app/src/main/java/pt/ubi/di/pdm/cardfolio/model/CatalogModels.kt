package pt.ubi.di.pdm.cardfolio.model

import java.util.UUID

/** What kind of cards a category holds — drives the labels in the rankings. */
enum class CategoryType(val displayName: String) {
    SPORT("Desporto"),           // Futebol, Basquetebol, Ténis…
    TCG("Jogo de Cartas"),       // Pokémon, Magic, Yu-Gi-Oh…
    OTHER("Outros")
}

/** Any entry of the user's catalog (category, collection, player or club). */
sealed interface CatalogEntry {
    val id: String
    val name: String
    val isArchived: Boolean

    fun toggledArchive(): CatalogEntry = when (this) {
        is CategoryCatalogItem -> copy(isArchived = !isArchived)
        is CollectionCatalogItem -> copy(isArchived = !isArchived)
        is PlayerCatalogItem -> copy(isArchived = !isArchived)
        is ClubCatalogItem -> copy(isArchived = !isArchived)
    }
}

data class CategoryCatalogItem(
    override val id: String = UUID.randomUUID().toString(),
    override val name: String,
    val type: CategoryType = CategoryType.OTHER,
    override val isArchived: Boolean = false
) : CatalogEntry

data class CollectionCatalogItem(
    override val id: String = UUID.randomUUID().toString(),
    override val name: String,
    val season: String, // ex: "2024/25"
    val categoryId: String,
    val category: String = "", // category name, read-only
    val manufacturer: String? = null,
    override val isArchived: Boolean = false
) : CatalogEntry

data class PlayerCatalogItem(
    override val id: String = UUID.randomUUID().toString(),
    override val name: String,
    val categoryId: String,
    val sport: String = "", // category name (ex: "Futebol"), read-only
    val country: String? = null,
    override val isArchived: Boolean = false
) : CatalogEntry

data class ClubCatalogItem(
    override val id: String = UUID.randomUUID().toString(),
    override val name: String,
    val categoryId: String,
    val sport: String = "", // category name (ex: "Futebol"), read-only
    val country: String? = null,
    override val isArchived: Boolean = false
) : CatalogEntry
