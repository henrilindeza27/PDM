package pt.ubi.di.pdm.cardfolio.ui.components

import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import pt.ubi.di.pdm.cardfolio.R
import pt.ubi.di.pdm.cardfolio.ui.theme.LocalIsDarkMode

@Composable
fun CardfolioLogo(
    modifier: Modifier = Modifier
) {
    val isDark = LocalIsDarkMode.current
    val logoRes = if (isDark) R.drawable.logo_darkmode else R.drawable.logo_lightmode

    Image(
        painter = painterResource(id = logoRes),
        contentDescription = "CardFolio Logo",
        modifier = modifier
    )
}
