package pt.ubi.di.pdm.cardfolio.data

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import androidx.core.content.contentValuesOf
import androidx.sqlite.db.SupportSQLiteDatabase
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.model.CategoryType
import java.time.LocalDate

/**
 * Demo account and sample data, written straight through the SQLite connection while the
 * database is being opened, so it exists before the first query (e.g. the login) runs.
 * Login: henrique.costa@cardfolio.pt / password123
 */
internal object DemoSeed {

    private const val USER = "user_1"

    /** PasswordHasher hash of "password123", precomputed: hashing at startup takes about a second. */
    internal const val DEMO_PASSWORD_HASH = "Q2FyZEZvbGlvRGVtbyExNg==:m0oUAe0tkdC2QoxPrp8stxlxHmyBZfJyZ67924WIDB4="

    fun insertInto(db: SupportSQLiteDatabase, today: LocalDate = LocalDate.now()) {
        db.beginTransaction()
        try {
            db.insertRow(
                "users",
                "id" to USER, "name" to "Henrique Costa", "email" to "henrique.costa@cardfolio.pt",
                "passwordHash" to DEMO_PASSWORD_HASH, "photoUri" to null
            )
            // Seed categories labelled with their type: SPORT (atletas and clubes) or TCG (personagens)
            listOf(
                Triple("cat_1", "Futebol", CategoryType.SPORT),
                Triple("cat_2", "Pokémon", CategoryType.TCG),
                Triple("cat_3", "Basquetebol", CategoryType.SPORT),
                Triple("cat_4", "Ténis", CategoryType.SPORT),
                Triple("cat_5", "Outros", CategoryType.OTHER)
            ).forEach { (id, name, type) ->
                db.insertRow("categories", "id" to id, "userId" to USER, "name" to name, "type" to type.name, "isArchived" to false)
            }

            collection(db, "col_1", "cat_1", "Panini Select", "2023", "Panini")
            collection(db, "col_2", "cat_2", "Base Set", "1999", "Wizards of the Coast")
            collection(db, "col_3", "cat_1", "Topps Chrome", "2023", "Topps")

            person(db, "players", "player_1", "cat_1", "Cristiano Ronaldo", "Portugal")
            person(db, "players", "player_2", "cat_1", "Kylian Mbappé", "França")
            person(db, "players", "player_3", "cat_2", "Charizard", "Japão")
            person(db, "players", "player_4", "cat_2", "Pikachu", "Japão")

            person(db, "clubs", "club_1", "cat_1", "Portugal", "Portugal")
            person(db, "clubs", "club_2", "cat_1", "Real Madrid", "Espanha")
            person(db, "clubs", "club_3", "cat_1", "Paris Saint-Germain", "França")

            // Purchases spread over the last year so the evolution chart has a history
            listOf(
                CardEntity(
                    id = "card_1", userId = USER, categoryId = "cat_1", collectionId = "col_1", playerId = "player_1", clubId = "club_1",
                    name = "Cristiano Ronaldo", date = today.minusDays(10).toString(), costCents = 8500, valueCents = 12000,
                    purpose = CardPurpose.PERSONAL, status = CardStatus.KEPT
                ),
                CardEntity(
                    id = "card_2", userId = USER, categoryId = "cat_2", collectionId = "col_2", playerId = "player_3",
                    name = "Charizard", date = today.minusDays(150).toString(), costCents = 18000, valueCents = 24500, additionalCostCents = 1000,
                    purpose = CardPurpose.PERSONAL, status = CardStatus.KEPT, notes = "Portes de envio: 10 €"
                ),
                CardEntity(
                    id = "card_3", userId = USER, categoryId = "cat_1", collectionId = "col_3", playerId = "player_2", clubId = "club_3",
                    name = "Kylian Mbappé", date = today.minusDays(14).toString(), costCents = 4500, valueCents = 7500,
                    purpose = CardPurpose.RESALE, status = CardStatus.LISTED
                ),
                CardEntity(
                    id = "card_4", userId = USER, categoryId = "cat_2", collectionId = "col_2", playerId = "player_4",
                    name = "Pikachu", date = today.minusDays(300).toString(), costCents = 3500, valueCents = 5500,
                    purpose = CardPurpose.PERSONAL, status = CardStatus.KEPT
                )
            ).forEach { db.insertCard(it) }

            // Completed resales dated relative to today, so every sales period filter has data.
            // Mix of profits, one loss and extra costs (shipping) to exercise the finance screens.
            listOf(
                SoldSeed("card_5", "Erling Haaland", "cat_1", "col_3", 6000, 500, 11000, daysAgo = 0),
                SoldSeed("card_6", "Mewtwo", "cat_2", "col_2", 9000, 0, 15000, daysAgo = 3),
                SoldSeed("card_7", "Jude Bellingham", "cat_1", "col_1", 4000, 400, 3800, daysAgo = 20),
                SoldSeed("card_8", "Blastoise", "cat_2", "col_2", 12000, 600, 21000, daysAgo = 120),
                SoldSeed("card_9", "Lamine Yamal", "cat_1", "col_3", 2500, 300, 7000, daysAgo = 400)
            ).forEach { sale ->
                val saleDate = today.minusDays(sale.daysAgo)
                db.insertCard(
                    CardEntity(
                        id = sale.id, userId = USER, categoryId = sale.categoryId, collectionId = sale.collectionId,
                        name = sale.name, date = saleDate.minusDays(30).toString(),
                        costCents = sale.costCents, additionalCostCents = sale.extraCents, valueCents = sale.saleCents,
                        purpose = CardPurpose.RESALE, status = CardStatus.SOLD,
                        salePriceCents = sale.saleCents, saleDate = saleDate.toString()
                    )
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private data class SoldSeed(
        val id: String,
        val name: String,
        val categoryId: String,
        val collectionId: String,
        val costCents: Long,
        val extraCents: Long,
        val saleCents: Long,
        val daysAgo: Long
    )

    private fun collection(db: SupportSQLiteDatabase, id: String, categoryId: String, name: String, season: String, manufacturer: String) =
        db.insertRow(
            "collections",
            "id" to id, "userId" to USER, "categoryId" to categoryId, "name" to name,
            "season" to season, "manufacturer" to manufacturer, "isArchived" to false
        )

    /** Players and clubs share the same columns. */
    private fun person(db: SupportSQLiteDatabase, table: String, id: String, categoryId: String, name: String, country: String) =
        db.insertRow(
            table,
            "id" to id, "userId" to USER, "categoryId" to categoryId, "name" to name, "country" to country, "isArchived" to false
        )

    // Column names must match CardEntity (Room stores enums by name)
    private fun SupportSQLiteDatabase.insertCard(c: CardEntity) = insertRow(
        "cards",
        "id" to c.id, "userId" to c.userId, "categoryId" to c.categoryId,
        "collectionId" to c.collectionId, "playerId" to c.playerId, "clubId" to c.clubId,
        "name" to c.name, "date" to c.date,
        "costCents" to c.costCents, "valueCents" to c.valueCents, "additionalCostCents" to c.additionalCostCents,
        "purpose" to c.purpose.name, "status" to c.status.name, "imageUri" to c.imageUri,
        "salePriceCents" to c.salePriceCents, "saleDate" to c.saleDate,
        "cardNumber" to c.cardNumber, "variant" to c.variant,
        "isAutograph" to c.isAutograph, "isPatch" to c.isPatch, "isRookie" to c.isRookie, "isNumbered" to c.isNumbered,
        "numberedCopy" to c.numberedCopy, "numberedTotal" to c.numberedTotal,
        "platform" to c.platform, "notes" to c.notes
    )

    private fun SupportSQLiteDatabase.insertRow(table: String, vararg values: Pair<String, Any?>) {
        val row: ContentValues = contentValuesOf(*values)
        insert(table, SQLiteDatabase.CONFLICT_ABORT, row)
    }
}
