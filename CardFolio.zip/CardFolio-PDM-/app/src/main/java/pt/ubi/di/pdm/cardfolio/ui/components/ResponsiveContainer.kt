package pt.ubi.di.pdm.cardfolio.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Centra o conteúdo e limita-lhe a largura máxima em ecrãs grandes (tablet, landscape),
 * para o texto e os cartões não ficarem esticados numa linha longa.
 */
@Composable
fun ResponsiveContainer(
    modifier: Modifier = Modifier,
    maxContentWidth: Int = 700,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = maxContentWidth.dp)
        ) {
            content()
        }
    }
}
