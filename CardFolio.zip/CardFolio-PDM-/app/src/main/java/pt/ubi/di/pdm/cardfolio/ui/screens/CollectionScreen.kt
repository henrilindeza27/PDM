package pt.ubi.di.pdm.cardfolio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.automirrored.outlined.List
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.ubi.di.pdm.cardfolio.ui.components.rememberCsvExporter
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.SortMode
import pt.ubi.di.pdm.cardfolio.model.StatusFilter
import pt.ubi.di.pdm.cardfolio.ui.components.CardItemGridCard
import pt.ubi.di.pdm.cardfolio.ui.components.DropdownField
import pt.ubi.di.pdm.cardfolio.ui.components.CardItemListRow
import pt.ubi.di.pdm.cardfolio.ui.components.KpiBar
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectionScreen(
    viewModel: CardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val exportCsv = rememberCsvExporter(viewModel)
    val cards by viewModel.filteredCollectionCards.collectAsState()
    val allCards by viewModel.allCards.collectAsState()
    val collectionTab by viewModel.collectionTab.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedStatusFilter by viewModel.selectedStatusFilter.collectAsState()
    val availableCategories by viewModel.availableCategories.collectAsState()
    val isGridView by viewModel.isGridView.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()

    val collectionValue by viewModel.collectionValue.collectAsState()
    val personalInvestment by viewModel.personalInvestment.collectAsState()
    val personalCollection by viewModel.personalCollection.collectAsState()
    val resaleProfit by viewModel.resaleProfit.collectAsState()
    val resaleCompletedSalesCount by viewModel.resaleCompletedSalesCount.collectAsState()
    val resaleStockCount by viewModel.resaleStockCount.collectAsState()
    val resaleStockInvestment by viewModel.resaleStockInvestment.collectAsState()

    val personalCardsCount = personalCollection.size
    val resaleCardsCount = allCards.count { it.purpose == CardPurpose.RESALE }

    // Adaptativo: 2 colunas em telemóvel, 3-4 em tablet; 1 em modo lista
    LazyVerticalGrid(
        columns = if (isGridView) GridCells.Adaptive(minSize = 170.dp) else GridCells.Fixed(1),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header & Title Block
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f, fill = false)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "A minha coleção",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "Gere as tuas peças, estimativa de valor e inventário.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { viewModel.openNewCardEditor() },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryIndigo,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Add,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Adicionar carta",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // KPI Bar
        item(span = { GridItemSpan(maxLineSpan) }) {
            KpiBar(
                collectionValue = collectionValue,
                personalInvestment = personalInvestment,
                personalCardsCount = personalCardsCount,
                categoriesCount = (availableCategories.size - 1).coerceAtLeast(0),
                resaleProfit = resaleProfit,
                resaleCompletedSalesCount = resaleCompletedSalesCount,
                resaleStockCount = resaleStockCount,
                resaleStockInvestment = resaleStockInvestment,
                modifier = Modifier.padding(horizontal = 0.dp)
            )
        }

        // Filter Tabs & Export CSV Button
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TabRow(
                    selectedTabIndex = collectionTab,
                    modifier = Modifier.weight(1f),
                    containerColor = SurfaceWhite,
                    contentColor = PrimaryIndigo,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[collectionTab]),
                            color = PrimaryIndigo
                        )
                    }
                ) {
                    Tab(
                        selected = collectionTab == 0,
                        onClick = { viewModel.setCollectionTab(0) },
                        text = { Text("Todas (${allCards.size})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = collectionTab == 1,
                        onClick = { viewModel.setCollectionTab(1) },
                        text = { Text("Pessoal ($personalCardsCount)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = collectionTab == 2,
                        onClick = { viewModel.setCollectionTab(2) },
                        text = { Text("Revenda ($resaleCardsCount)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedButton(
                    onClick = {
                        exportCsv()
                    },
                    modifier = Modifier.height(36.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(imageVector = Icons.Outlined.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("CSV", fontSize = 11.sp)
                }
            }
        }

        // Search Bar & Filter Controls
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Row 1: Search Field + Grid/List Toggle Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text("Pesquisar por nome ou edição...", fontSize = 13.sp) },
                        leadingIcon = { Icon(imageVector = Icons.Outlined.Search, contentDescription = null, tint = TextMuted) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(
                        onClick = { viewModel.toggleViewMode() },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(TagBackground)
                            .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            imageVector = if (isGridView) Icons.AutoMirrored.Outlined.List else Icons.Outlined.GridView,
                            contentDescription = "Alternar visualização",
                            tint = PrimaryIndigo
                        )
                    }
                }

                // Row 2: Category & Status Dropdowns (2 per row for ample width)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DropdownField(
                        value = selectedCategory,
                        options = availableCategories,
                        onSelect = viewModel::setSelectedCategory,
                        label = "Categoria",
                        compact = true,
                        modifier = Modifier.weight(1f)
                    )
                    DropdownField(
                        value = selectedStatusFilter.label,
                        options = StatusFilter.entries,
                        onSelect = viewModel::setSelectedStatusFilter,
                        optionLabel = { it.label },
                        label = "Estado",
                        compact = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 3: Sort Dropdown
                DropdownField(
                    value = sortMode.label,
                    options = SortMode.entries,
                    onSelect = viewModel::setSortMode,
                    optionLabel = { it.label },
                    label = "Ordenar por",
                    compact = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Cards List / Grid
        if (cards.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Nenhuma carta encontrada com os filtros selecionados.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            items(cards, key = { it.id }) { card ->
                if (isGridView) {
                    CardItemGridCard(
                        card = card,
                        onClick = { viewModel.openCardDetail(card) },
                        onEditClick = { viewModel.openEditCardEditor(card) },
                        onTogglePurposeClick = { viewModel.togglePurpose(card) },
                        onListCardClick = { viewModel.promptListCard(card) },
                        onRegisterSaleClick = { viewModel.promptRegisterSale(card) },
                        onDeleteClick = { viewModel.promptDeleteCard(card) }
                    )
                } else {
                    CardItemListRow(
                        card = card,
                        onClick = { viewModel.openCardDetail(card) },
                        onEditClick = { viewModel.openEditCardEditor(card) },
                        onTogglePurposeClick = { viewModel.togglePurpose(card) },
                        onListCardClick = { viewModel.promptListCard(card) },
                        onRegisterSaleClick = { viewModel.promptRegisterSale(card) },
                        onDeleteClick = { viewModel.promptDeleteCard(card) }
                    )
                }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
