package pt.ubi.di.pdm.cardfolio.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalIsDarkMode = compositionLocalOf { false }

// Dynamic Background & Surface
val OffWhiteBackground: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF0F172A) else Color(0xFFF8FAFC)

val SurfaceWhite: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF1E293B) else Color(0xFFFFFFFF)

val BorderSubtle: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF334155) else Color(0xFFE2E8F0)

// Primary / Highlight (Deep Emerald Green #059669)
val PrimaryIndigo = Color(0xFF059669)

val PrimaryIndigoSoft: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF064E3B) else Color(0xFFECFDF5)

val OnPrimaryIndigo = Color(0xFFFFFFFF)

// Success / Profit
val SuccessGreen = Color(0xFF059669)

val SuccessGreenSoft: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF064E3B) else Color(0xFFECFDF5)

// Warning / Stock (Amber)
val WarningAmber = Color(0xFFD97706)

val WarningAmberSoft: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF451A03) else Color(0xFFFFFBEB)

// Info (Blue) and secondary accent (Green) used by stats badges
val InfoBlue = Color(0xFF0284C7)

val InfoBlueSoft: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF0C4A6E) else Color(0xFFE0F2FE)

val AccentGreen = Color(0xFF16A34A)

val AccentGreenSoft: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF14532D) else Color(0xFFDCFCE7)

// Loss / negative results
val LossRed = Color(0xFFDC2626)

val LossRedSoft: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF450A0A) else Color(0xFFFEE2E2)

// Podium medals
val MedalGold = Color(0xFFD97706)
val MedalSilver = Color(0xFF64748B)
val MedalBronze = Color(0xFFB45309)

// Text & Contrast
val TextPrimary: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFFF8FAFC) else Color(0xFF0F172A)

val TextSecondary: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF94A3B8) else Color(0xFF64748B)

val TextMuted: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF64748B) else Color(0xFF94A3B8)

// Tag / Chip Background
val TagBackground: Color
    @Composable get() = if (LocalIsDarkMode.current) Color(0xFF1E293B) else Color(0xFFF1F5F9)
