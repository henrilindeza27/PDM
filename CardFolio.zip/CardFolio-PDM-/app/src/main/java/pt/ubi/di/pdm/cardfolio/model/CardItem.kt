package pt.ubi.di.pdm.cardfolio.model

import java.util.UUID

enum class CardPurpose {
    PERSONAL, RESALE
}

enum class CardStatus {
    KEPT, LISTED, SOLD
}

data class CardItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val categoryId: String,
    val category: String = "", // category name, read-only (comes from the categories table)
    val edition: String = "", // "Coleção · Época", read-only (derived from the collection)
    val date: String, // ISO date "YYYY-MM-DD"
    val cost: Double, // Preço de compra
    val value: Double, // Valor estimado de mercado ou preço pretendido
    val purpose: CardPurpose, // Coleção pessoal vs Revenda
    val status: CardStatus, // KEPT (guardada/stock), LISTED (à venda), SOLD (vendida)
    val imageUri: String? = null,
    val salePrice: Double? = null, // Preço final obtido na venda
    val saleDate: String? = null,
    val collectionId: String? = null,
    val playerId: String? = null,
    val clubId: String? = null,
    val cardNumber: String? = null,
    val variant: String? = null,
    val isAutograph: Boolean = false,
    val isPatch: Boolean = false,
    val isRookie: Boolean = false,
    val isNumbered: Boolean = false,
    val numberedCopy: Int? = null,
    val numberedTotal: Int? = null,
    val additionalCost: Double = 0.0,
    val platform: String? = null,
    val notes: String? = null
)
