package pt.ubi.di.pdm.cardfolio.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import pt.ubi.di.pdm.cardfolio.data.NO_COLLECTION_EDITION
import pt.ubi.di.pdm.cardfolio.model.CardItem
import pt.ubi.di.pdm.cardfolio.model.CardPurpose
import pt.ubi.di.pdm.cardfolio.model.CardStatus
import pt.ubi.di.pdm.cardfolio.model.CatalogEntry
import pt.ubi.di.pdm.cardfolio.model.CategoryCatalogItem
import pt.ubi.di.pdm.cardfolio.model.ClubCatalogItem
import pt.ubi.di.pdm.cardfolio.model.CollectionCatalogItem
import pt.ubi.di.pdm.cardfolio.model.PlayerCatalogItem
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmberSoft
import pt.ubi.di.pdm.cardfolio.util.FormatUtils
import pt.ubi.di.pdm.cardfolio.util.ImageStorage
import kotlinx.coroutines.launch
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardFormModalBottomSheet(
    cardToEdit: CardItem?,
    categories: List<CategoryCatalogItem>,
    collections: List<CollectionCatalogItem>,
    players: List<PlayerCatalogItem>,
    clubs: List<ClubCatalogItem>,
    onDismiss: () -> Unit,
    onSave: (CardItem) -> Unit,
    onAddCatalogEntry: (CatalogEntry) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var name by remember { mutableStateOf(cardToEdit?.name ?: "") }
    var selectedCategoryId by remember { mutableStateOf(cardToEdit?.categoryId ?: categories.firstOrNull { !it.isArchived }?.id ?: "") }
    var selectedCollectionId by remember { mutableStateOf(cardToEdit?.collectionId ?: collections.firstOrNull()?.id) }
    var selectedPlayerId by remember { mutableStateOf(cardToEdit?.playerId) }
    var selectedClubId by remember { mutableStateOf(cardToEdit?.clubId) }

    var cardNumber by remember { mutableStateOf(cardToEdit?.cardNumber ?: "") }
    var variant by remember { mutableStateOf(cardToEdit?.variant ?: "") }

    var isAutograph by remember { mutableStateOf(cardToEdit?.isAutograph ?: false) }
    var isPatch by remember { mutableStateOf(cardToEdit?.isPatch ?: false) }
    var isRookie by remember { mutableStateOf(cardToEdit?.isRookie ?: false) }
    var isNumbered by remember { mutableStateOf(cardToEdit?.isNumbered ?: false) }
    var numberedCopyInput by remember { mutableStateOf(cardToEdit?.numberedCopy?.toString() ?: "") }
    var numberedTotalInput by remember { mutableStateOf(cardToEdit?.numberedTotal?.toString() ?: "") }

    var purpose by remember { mutableStateOf(cardToEdit?.purpose ?: CardPurpose.PERSONAL) }
    var date by remember { mutableStateOf(cardToEdit?.date ?: LocalDate.now().toString()) }
    var costInput by remember { mutableStateOf(cardToEdit?.cost?.toString() ?: "0.0") }
    var valueInput by remember { mutableStateOf(cardToEdit?.value?.toString() ?: "0.0") }
    var additionalCostInput by remember { mutableStateOf(cardToEdit?.additionalCost?.toString() ?: "0.0") }
    var platform by remember { mutableStateOf(cardToEdit?.platform ?: "") }
    var notes by remember { mutableStateOf(cardToEdit?.notes ?: "") }
    var imageUri by remember { mutableStateOf(cardToEdit?.imageUri) }

    // Quick add dialogs
    var showQuickAddCollection by remember { mutableStateOf(false) }
    var showQuickAddPlayer by remember { mutableStateOf(false) }
    var showQuickAddClub by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                ImageStorage.copyToAppStorage(context, it)?.let { saved -> imageUri = saved }
                    ?: Toast.makeText(context, "Não foi possível carregar a imagem.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val selectedCategory = categories.find { it.id == selectedCategoryId }?.name ?: ""
    val activeCollections = collections.filter { !it.isArchived && it.categoryId == selectedCategoryId }
    val activePlayers = players.filter { !it.isArchived }
    val activeClubs = clubs.filter { !it.isArchived }

    val isSports = selectedCategory.equals("Futebol", true) || selectedCategory.equals("Basquetebol", true) || selectedCategory.equals("Ténis", true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (cardToEdit != null) "Editar Carta" else "Adicionar Nova Carta",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            // 1. FOTOGRAFIA
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(TagBackground)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                    .clickable { photoPickerLauncher.launch(arrayOf("image/*")) },
                contentAlignment = Alignment.Center
            ) {
                if (!imageUri.isNullOrEmpty()) {
                    AsyncImage(
                        model = imageUri,
                        contentDescription = "Foto da carta",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.AddAPhoto,
                            contentDescription = "Adicionar Foto",
                            tint = PrimaryIndigo,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Adicionar Fotografia (Opcional)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary
                        )
                    }
                }
            }

            // 2. IDENTIFICAÇÃO
            FormSectionHeader("Identificação")

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nome da Carta (obrigatório)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            DropdownField(
                value = selectedCategory,
                options = categories.filter { !it.isArchived },
                optionLabel = { it.name },
                onSelect = {
                    // collection, player and club belong to a category: reset them when it changes
                    if (it.id != selectedCategoryId) {
                        selectedCategoryId = it.id
                        selectedCollectionId = null
                        selectedPlayerId = null
                        selectedClubId = null
                    }
                },
                label = "Categoria",
                modifier = Modifier.fillMaxWidth()
            )

            val currentCollection = collections.find { it.id == selectedCollectionId }
            CatalogPickerRow(
                value = currentCollection?.let { "${it.name} · ${it.season}" } ?: "Selecionar coleção...",
                label = "Coleção / Edição",
                options = activeCollections,
                optionLabel = { "${it.name} · ${it.season}" },
                onSelect = { selectedCollectionId = it.id },
                onCreateClick = { showQuickAddCollection = true }
            )

            OutlinedTextField(
                value = cardNumber,
                onValueChange = { cardNumber = it },
                label = { Text("Número da carta na coleção (opcional, ex: 125)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 3. JOGADOR E CLUBE (se desporto)
            if (isSports) {
                FormSectionHeader("Atleta e Equipa")

                val noPlayer = "Nenhum / Sem atleta individual"
                CatalogPickerRow(
                    value = players.find { it.id == selectedPlayerId }?.name ?: noPlayer,
                    label = "Jogador / Atleta",
                    options = listOf(null) + activePlayers.filter { it.categoryId == selectedCategoryId },
                    optionLabel = { it?.name ?: noPlayer },
                    onSelect = { selectedPlayerId = it?.id },
                    onCreateClick = { showQuickAddPlayer = true }
                )

                val noClub = "Nenhum / Sem clube associado"
                CatalogPickerRow(
                    value = clubs.find { it.id == selectedClubId }?.name ?: noClub,
                    label = "Clube / Equipa",
                    options = listOf(null) + activeClubs.filter { it.categoryId == selectedCategoryId },
                    optionLabel = { it?.name ?: noClub },
                    onSelect = { selectedClubId = it?.id },
                    onCreateClick = { showQuickAddClub = true }
                )
            }

            // 4. CARACTERÍSTICAS
            FormSectionHeader("Características")

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isAutograph, onCheckedChange = { isAutograph = it })
                    Text("Autografada", fontSize = 13.sp, color = TextPrimary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPatch, onCheckedChange = { isPatch = it })
                    Text("Patch / Memorabilia", fontSize = 13.sp, color = TextPrimary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isRookie, onCheckedChange = { isRookie = it })
                    Text("Rookie Card (RC)", fontSize = 13.sp, color = TextPrimary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isNumbered, onCheckedChange = { isNumbered = it })
                    Text("Numerada", fontSize = 13.sp, color = TextPrimary)
                }
            }

            if (isNumbered) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = numberedCopyInput,
                        onValueChange = { numberedCopyInput = it },
                        label = { Text("Exemplar (ex: 17)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = numberedTotalInput,
                        onValueChange = { numberedTotalInput = it },
                        label = { Text("Tiragem (ex: 99)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            OutlinedTextField(
                value = variant,
                onValueChange = { variant = it },
                label = { Text("Variante / Paralelo (opcional, ex: Silver, Gold)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 5. AQUISIÇÃO E FINALIDADE
            FormSectionHeader("Aquisição e Finalidade")

            Text("Finalidade da Carta", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextSecondary)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            1.dp,
                            if (purpose == CardPurpose.PERSONAL) PrimaryIndigo else BorderSubtle,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { purpose = CardPurpose.PERSONAL },
                    color = if (purpose == CardPurpose.PERSONAL) PrimaryIndigoSoft else SurfaceWhite
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Favorite,
                            contentDescription = null,
                            tint = if (purpose == CardPurpose.PERSONAL) PrimaryIndigo else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Coleção Pessoal",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (purpose == CardPurpose.PERSONAL) PrimaryIndigo else TextSecondary
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            1.dp,
                            if (purpose == CardPurpose.RESALE) WarningAmber else BorderSubtle,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { purpose = CardPurpose.RESALE },
                    color = if (purpose == CardPurpose.RESALE) WarningAmberSoft else SurfaceWhite
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.SwapHoriz,
                            contentDescription = null,
                            tint = if (purpose == CardPurpose.RESALE) WarningAmber else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Para Revenda",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (purpose == CardPurpose.RESALE) WarningAmber else TextSecondary
                        )
                    }
                }
            }

            DatePickerField(
                label = "Data de aquisição",
                dateValue = date,
                onDateSelected = { date = it }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = costInput,
                    onValueChange = { costInput = it },
                    label = { Text("Preço Compra (€)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = valueInput,
                    onValueChange = { valueInput = it },
                    label = { Text("Valor Estimado (€)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            // 6. MAIS DETALHES (OPCIONAL)
            FormSectionHeader("Mais detalhes (opcional)")

            OutlinedTextField(
                value = additionalCostInput,
                onValueChange = { additionalCostInput = it },
                label = { Text("Custos adicionais / portes (€)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = platform,
                onValueChange = { platform = it },
                label = { Text("Plataforma / Local de compra (ex: eBay, OLX)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notas") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Save & Cancel Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Cancelar")
                }

                Button(
                    onClick = {
                        if (name.isNotBlank() && selectedCategoryId.isNotBlank()) {
                            val selectedCol = collections.find { it.id == selectedCollectionId }
                            val editionText = if (selectedCol != null) "${selectedCol.name} · ${selectedCol.season}" else NO_COLLECTION_EDITION

                            val newItem = (cardToEdit ?: CardItem(
                                name = name,
                                categoryId = selectedCategoryId,
                                date = date,
                                cost = 0.0,
                                value = 0.0,
                                purpose = purpose,
                                status = CardStatus.KEPT
                            )).copy(
                                name = name.trim(),
                                edition = editionText,
                                categoryId = selectedCategoryId,
                                category = selectedCategory,
                                collectionId = selectedCollectionId,
                                playerId = selectedPlayerId,
                                clubId = selectedClubId,
                                cardNumber = cardNumber.ifBlank { null },
                                variant = variant.ifBlank { null },
                                isAutograph = isAutograph,
                                isPatch = isPatch,
                                isRookie = isRookie,
                                isNumbered = isNumbered,
                                numberedCopy = numberedCopyInput.toIntOrNull(),
                                numberedTotal = numberedTotalInput.toIntOrNull(),
                                date = date.ifBlank { LocalDate.now().toString() },
                                cost = FormatUtils.parseDecimal(costInput) ?: 0.0,
                                value = FormatUtils.parseDecimal(valueInput) ?: 0.0,
                                additionalCost = FormatUtils.parseDecimal(additionalCostInput) ?: 0.0,
                                purpose = purpose,
                                platform = platform.ifBlank { null },
                                notes = notes.ifBlank { null },
                                imageUri = imageUri
                            )
                            onSave(newItem)
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryIndigo,
                        contentColor = Color.White
                    ),
                    enabled = name.isNotBlank() && selectedCategoryId.isNotBlank()
                ) {
                    Text("Guardar Carta", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Quick Add Collection Dialog
    if (showQuickAddCollection) {
        var newColName by remember { mutableStateOf("") }
        var newColSeason by remember { mutableStateOf("2024/25") }
        AlertDialog(
            onDismissRequest = { showQuickAddCollection = false },
            title = { Text("Adicionar Coleção") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = newColName, onValueChange = { newColName = it }, label = { Text("Nome (ex: Topps Chrome)") }, singleLine = true)
                    OutlinedTextField(value = newColSeason, onValueChange = { newColSeason = it }, label = { Text("Época (ex: 2024/25)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newColName.isNotBlank()) {
                            val newCol = CollectionCatalogItem(name = newColName.trim(), season = newColSeason.trim(), categoryId = selectedCategoryId, category = selectedCategory)
                            onAddCatalogEntry(newCol)
                            selectedCollectionId = newCol.id
                            showQuickAddCollection = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                ) {
                    Text("Criar e Selecionar", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showQuickAddCollection = false }) { Text("Cancelar") }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Quick Add Player Dialog
    if (showQuickAddPlayer) {
        var newPlayerName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showQuickAddPlayer = false },
            title = { Text("Adicionar Jogador") },
            text = {
                OutlinedTextField(value = newPlayerName, onValueChange = { newPlayerName = it }, label = { Text("Nome do Jogador") }, singleLine = true)
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPlayerName.isNotBlank()) {
                            val newP = PlayerCatalogItem(name = newPlayerName.trim(), categoryId = selectedCategoryId, sport = selectedCategory)
                            onAddCatalogEntry(newP)
                            selectedPlayerId = newP.id
                            showQuickAddPlayer = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                ) {
                    Text("Criar e Selecionar", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showQuickAddPlayer = false }) { Text("Cancelar") }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Quick Add Club Dialog
    if (showQuickAddClub) {
        var newClubName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showQuickAddClub = false },
            title = { Text("Adicionar Clube") },
            text = {
                OutlinedTextField(value = newClubName, onValueChange = { newClubName = it }, label = { Text("Nome do Clube") }, singleLine = true)
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newClubName.isNotBlank()) {
                            val newC = ClubCatalogItem(name = newClubName.trim(), categoryId = selectedCategoryId, sport = selectedCategory)
                            onAddCatalogEntry(newC)
                            selectedClubId = newC.id
                            showQuickAddClub = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                ) {
                    Text("Criar e Selecionar", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showQuickAddClub = false }) { Text("Cancelar") }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun FormSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = PrimaryIndigo,
        modifier = Modifier.padding(top = 4.dp)
    )
}

/** Catalog dropdown with a "Criar" button next to it for quick-adding a new entry. */
@Composable
private fun <T> CatalogPickerRow(
    value: String,
    label: String,
    options: List<T>,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit,
    onCreateClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DropdownField(
            value = value,
            options = options,
            onSelect = onSelect,
            optionLabel = optionLabel,
            label = label,
            modifier = Modifier.weight(1f)
        )
        OutlinedButton(
            onClick = onCreateClick,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.height(56.dp)
        ) {
            Icon(imageVector = Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(2.dp))
            Text("Criar", fontSize = 11.sp)
        }
    }
}
