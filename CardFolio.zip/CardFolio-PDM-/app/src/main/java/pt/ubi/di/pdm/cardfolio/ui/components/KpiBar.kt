package pt.ubi.di.pdm.cardfolio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRed
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreen
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreenSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmber
import pt.ubi.di.pdm.cardfolio.ui.theme.WarningAmberSoft
import pt.ubi.di.pdm.cardfolio.util.FormatUtils

@Composable
fun KpiBar(
    collectionValue: Double,
    personalInvestment: Double,
    personalCardsCount: Int,
    categoriesCount: Int,
    resaleProfit: Double,
    resaleCompletedSalesCount: Int,
    resaleStockCount: Int,
    resaleStockInvestment: Double,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 1: Valor da coleção
            KpiCard(
                title = "Valor da coleção",
                valueText = FormatUtils.formatCurrency(collectionValue),
                icon = Icons.Outlined.AccountBalanceWallet,
                iconTint = PrimaryIndigo,
                iconBackground = PrimaryIndigoSoft,
                subtext = "${FormatUtils.formatCurrency(personalInvestment)} investidos",
                modifier = Modifier.weight(1f)
            )

            // Card 2: Cartas na coleção
            KpiCard(
                title = "Cartas na coleção",
                valueText = String.format("%02d", personalCardsCount),
                icon = Icons.Outlined.Layers,
                iconTint = PrimaryIndigo,
                iconBackground = PrimaryIndigoSoft,
                subtext = "$categoriesCount categorias na coleção",
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 3: Lucro de revenda
            KpiCard(
                title = "Lucro de revenda",
                valueText = FormatUtils.formatCurrency(resaleProfit, includePlusSign = true),
                valueColor = if (resaleProfit >= 0) SuccessGreen else LossRed,
                icon = Icons.AutoMirrored.Outlined.TrendingUp,
                iconTint = SuccessGreen,
                iconBackground = SuccessGreenSoft,
                subtext = "$resaleCompletedSalesCount vendas concluídas",
                modifier = Modifier.weight(1f)
            )

            // Card 4: Stock para revenda
            KpiCard(
                title = "Stock para revenda",
                valueText = String.format("%02d", resaleStockCount),
                icon = Icons.Outlined.SwapHoriz,
                iconTint = WarningAmber,
                iconBackground = WarningAmberSoft,
                subtext = "${FormatUtils.formatCurrency(resaleStockInvestment)} em investimento",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun KpiCard(
    title: String,
    valueText: String,
    icon: ImageVector,
    iconTint: Color,
    iconBackground: Color,
    subtext: String,
    modifier: Modifier = Modifier,
    valueColor: Color = TextPrimary
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp)),
        color = SurfaceWhite
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(iconBackground),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = valueText,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = subtext,
                fontSize = 11.sp,
                fontWeight = FontWeight.Normal,
                color = TextMuted
            )
        }
    }
}
