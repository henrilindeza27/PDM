package pt.ubi.di.pdm.cardfolio.util

import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

object FormatUtils {

    var hideCurrencyValues: Boolean = false

    private val portugueseLocale = Locale.forLanguageTag("pt-PT")

    /**
     * Parses user-typed amounts accepting both "85,50" and "85.50"
     */
    fun parseDecimal(input: String): Double? = input.trim().replace(',', '.').toDoubleOrNull()

    /**
     * Formats currency as Portuguese Euro format: "85,00 €" or "+80,00 €"
     */
    fun formatCurrency(value: Double, includePlusSign: Boolean = false): String {
        if (hideCurrencyValues) return "•••• €"
        val numberFormat = NumberFormat.getCurrencyInstance(portugueseLocale).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
        var formatted = numberFormat.format(value)
        if (value > 0 && includePlusSign) {
            formatted = "+$formatted"
        }
        return formatted
    }

    /**
     * Formats a percentage in Portuguese style: "40,5%" or "+40,5%"
     */
    fun formatPercent(value: Double, includePlusSign: Boolean = false): String {
        val formatted = String.format(portugueseLocale, "%.1f%%", value)
        return if (value > 0 && includePlusSign) "+$formatted" else formatted
    }

    /**
     * Whole euros for chart axes: "420 €" (hidden as "•• €" like the other amounts)
     */
    fun formatCurrencyShort(value: Double): String {
        if (hideCurrencyValues) return "•• €"
        return NumberFormat.getCurrencyInstance(portugueseLocale).apply { maximumFractionDigits = 0 }.format(value)
    }

    /**
     * Formats a "YYYY-MM" month into "out 2026"
     */
    fun formatMonth(isoMonth: String): String =
        runCatching { formatMonth(YearMonth.parse(isoMonth)) }.getOrDefault(isoMonth)

    fun formatMonth(month: YearMonth): String =
        month.format(DateTimeFormatter.ofPattern("MMM yyyy", portugueseLocale)).withoutDots()

    /** Month name only, for chart labels: "out" */
    fun formatMonthShort(month: YearMonth): String =
        month.format(DateTimeFormatter.ofPattern("MMM", portugueseLocale)).withoutDots()

    // Some Java versions abbreviate Portuguese months as "out." and Android as "out": keep one style
    private fun String.withoutDots() = replace(".", "")

    /**
     * Formats ISO date String "YYYY-MM-DD" into short Portuguese date "12 out 2026"
     */
    fun formatDateShort(isoDate: String?): String {
        if (isoDate.isNullOrEmpty()) return "—"
        return try {
            val parsed = LocalDate.parse(isoDate)
            val formatter = DateTimeFormatter.ofPattern("dd MMM yyyy", portugueseLocale)
            parsed.format(formatter).withoutDots()
        } catch (e: Exception) {
            isoDate
        }
    }
}
