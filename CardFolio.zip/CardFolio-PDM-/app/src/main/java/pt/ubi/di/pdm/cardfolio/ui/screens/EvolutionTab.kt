package pt.ubi.di.pdm.cardfolio.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.ubi.di.pdm.cardfolio.ui.components.SectionCard
import pt.ubi.di.pdm.cardfolio.ui.theme.BorderSubtle
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRed
import pt.ubi.di.pdm.cardfolio.ui.theme.LossRedSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.MedalSilver
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigo
import pt.ubi.di.pdm.cardfolio.ui.theme.PrimaryIndigoSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreen
import pt.ubi.di.pdm.cardfolio.ui.theme.SuccessGreenSoft
import pt.ubi.di.pdm.cardfolio.ui.theme.SurfaceWhite
import pt.ubi.di.pdm.cardfolio.ui.theme.TagBackground
import pt.ubi.di.pdm.cardfolio.ui.theme.TextMuted
import pt.ubi.di.pdm.cardfolio.ui.theme.TextPrimary
import pt.ubi.di.pdm.cardfolio.ui.theme.TextSecondary
import pt.ubi.di.pdm.cardfolio.util.CardStats
import pt.ubi.di.pdm.cardfolio.util.FormatUtils
import pt.ubi.di.pdm.cardfolio.util.GrowthPoint
import pt.ubi.di.pdm.cardfolio.util.MonthActivity
import pt.ubi.di.pdm.cardfolio.viewmodel.CardViewModel
import java.time.Month
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Evolution tab of the stats screen: how the personal collection grew (invested vs. estimated value)
 * and how much the resales earned each month. Both charts are interactive: tap a month to inspect it.
 */
@Composable
internal fun EvolutionTab(viewModel: CardViewModel) {
    val allCards by viewModel.allCards.collectAsState()
    val growth = remember(allCards) { CardStats.personalGrowth(allCards) }
    val activity = remember(allCards) { CardStats.monthlyActivity(allCards) }

    GrowthSection(growth)
    MonthlySalesSection(activity)
}

// ---------- Personal collection over time ----------

@Composable
private fun GrowthSection(points: List<GrowthPoint>) {
    SectionCard(title = "Coleção pessoal ao longo do tempo", subtitle = "Investido vs. valor estimado, mês a mês") {
        if (points.size < 2) {
            EmptyChart("Adiciona cartas à coleção pessoal para veres a evolução.")
            return@SectionCard
        }
        var selected by remember(points) { mutableIntStateOf(points.lastIndex) }
        val point = points[selected]
        val gain = point.value - point.invested

        Text(FormatUtils.formatMonth(point.month), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            LegendValue(PrimaryIndigo, "Valor estimado", FormatUtils.formatCurrency(point.value), Modifier.weight(1f))
            LegendValue(MedalSilver, "Investido", FormatUtils.formatCurrency(point.invested), Modifier.weight(1f))
            if (point.invested > 0) {
                Text(
                    text = FormatUtils.formatPercent(gain / point.invested * 100, true),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (gain < 0) LossRed else SuccessGreen,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (gain < 0) LossRedSoft else SuccessGreenSoft)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        GrowthChart(points = points, selected = selected, onSelect = { selected = it })
        Spacer(modifier = Modifier.height(6.dp))

        // X axis: first, middle and last month (the chart starts at the Y-axis labels' width)
        Row(modifier = Modifier.fillMaxWidth().padding(start = AXIS_WIDTH), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf(points.first(), points[points.size / 2], points.last()).distinct().forEach {
                Text(FormatUtils.formatMonth(it.month), fontSize = 10.sp, color = TextMuted)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            "O valor usa a estimativa atual de cada carta. Toca ou arrasta no gráfico para ver um mês.",
            fontSize = 11.sp,
            color = TextMuted
        )
    }
}

private val AXIS_WIDTH = 44.dp

@Composable
private fun GrowthChart(points: List<GrowthPoint>, selected: Int, onSelect: (Int) -> Unit) {
    val textMeasurer = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 10.sp, color = TextMuted)
    val gridColor = BorderSubtle
    val dotFill = SurfaceWhite
    val axis = remember(points) { niceAxis(points.maxOf { max(it.invested, it.value) }) }
    val maxY = axis.last()

    // Lines are drawn from left to right when the tab opens
    val reveal = remember(points) { Animatable(0f) }
    LaunchedEffect(points) { reveal.animateTo(1f, tween(durationMillis = 900)) }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .pointerInput(points) {
                val left = AXIS_WIDTH.toPx()
                fun indexAt(x: Float) =
                    (((x - left) / (size.width - left)) * points.lastIndex).roundToInt().coerceIn(0, points.lastIndex)
                detectTapGestures { onSelect(indexAt(it.x)) }
            }
            .pointerInput(points) {
                val left = AXIS_WIDTH.toPx()
                detectHorizontalDragGestures { change, _ ->
                    onSelect((((change.position.x - left) / (size.width - left)) * points.lastIndex).roundToInt().coerceIn(0, points.lastIndex))
                }
            }
    ) {
        val left = AXIS_WIDTH.toPx()
        val top = 8.dp.toPx()
        val chartWidth = size.width - left
        val chartHeight = size.height - top - 4.dp.toPx()
        fun x(i: Int) = left + chartWidth * i / points.lastIndex
        fun y(v: Double) = top + chartHeight * (1 - v / maxY).toFloat()

        // Y axis grid with labels
        axis.forEach { v ->
            val gy = y(v)
            drawLine(gridColor, Offset(left, gy), Offset(size.width, gy), strokeWidth = 1.dp.toPx())
            val label = textMeasurer.measure(FormatUtils.formatCurrencyShort(v), labelStyle)
            drawText(label, topLeft = Offset(0f, gy - label.size.height / 2f))
        }

        val valueLine = Path().apply { points.forEachIndexed { i, p -> if (i == 0) moveTo(x(i), y(p.value)) else lineTo(x(i), y(p.value)) } }
        val investedLine = Path().apply { points.forEachIndexed { i, p -> if (i == 0) moveTo(x(i), y(p.invested)) else lineTo(x(i), y(p.invested)) } }
        val valueArea = Path().apply {
            addPath(valueLine)
            lineTo(x(points.lastIndex), y(0.0))
            lineTo(x(0), y(0.0))
            close()
        }

        clipRect(right = left + chartWidth * reveal.value) {
            drawPath(valueArea, Brush.verticalGradient(listOf(PrimaryIndigo.copy(alpha = 0.25f), PrimaryIndigo.copy(alpha = 0f))))
            drawPath(investedLine, MedalSilver, style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))))
            drawPath(valueLine, PrimaryIndigo, style = Stroke(width = 3.dp.toPx()))
        }

        // Selected month marker
        val sx = x(selected)
        drawLine(PrimaryIndigo.copy(alpha = 0.35f), Offset(sx, top), Offset(sx, y(0.0)), strokeWidth = 1.5.dp.toPx())
        listOf(points[selected].invested to MedalSilver, points[selected].value to PrimaryIndigo).forEach { (v, color) ->
            drawCircle(color, radius = 6.dp.toPx(), center = Offset(sx, y(v)))
            drawCircle(dotFill, radius = 3.dp.toPx(), center = Offset(sx, y(v)))
        }
    }
}

/**
 * Round Y-axis ticks (0, 100, 200…) with a step of 1, 2 or 5 × 10ⁿ, at most 5 intervals.
 */
internal fun niceAxis(maxValue: Double): List<Double> {
    val top = maxValue.coerceAtLeast(1.0)
    val step = generateSequence(1.0) { it * 10 }
        .flatMap { sequenceOf(it, it * 2, it * 5) }
        .first { ceil(top / it) <= 5 }
    val intervals = ceil(top / step).toInt().let { if (it * step == top) it + 1 else it } // headroom above the top value
    return (0..intervals).map { it * step }
}

@Composable
private fun LegendValue(color: Color, label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(modifier = Modifier.width(6.dp))
            Text(label, fontSize = 11.sp, color = TextMuted)
        }
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
    }
}

// ---------- Resale results per month ----------

@Composable
private fun MonthlySalesSection(months: List<MonthActivity>) {
    SectionCard(title = "Lucro de revenda por mês", subtitle = "Toca num mês para ver o detalhe") {
        val sales = months.sumOf { it.sold }
        if (sales == 0) {
            EmptyChart("Ainda sem vendas concluídas.")
            return@SectionCard
        }
        val total = months.sumOf { it.profit }
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                FormatUtils.formatCurrency(total, true),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = if (total < 0) LossRed else SuccessGreen
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("em $sales ${if (sales == 1) "venda" else "vendas"}", fontSize = 12.sp, color = TextSecondary, modifier = Modifier.padding(bottom = 3.dp))
        }
        Spacer(modifier = Modifier.height(12.dp))

        // Starts on the most recent month that had any activity
        var selected by remember(months) { mutableIntStateOf(months.indexOfLast { it.sold > 0 || it.bought > 0 }.coerceAtLeast(0)) }
        ProfitBars(months = months, selected = selected, onSelect = { selected = it })
        Spacer(modifier = Modifier.height(12.dp))
        MonthDetail(months[selected])
    }
}

@Composable
private fun ProfitBars(months: List<MonthActivity>, selected: Int, onSelect: (Int) -> Unit) {
    val maxGain = months.maxOf { max(it.profit, 0.0) }
    val maxLoss = months.maxOf { max(-it.profit, 0.0) }
    val range = (maxGain + maxLoss).takeIf { it > 0 } ?: 1.0
    val chartHeight = 110.dp
    // Space above and below the zero line is proportional to the biggest gain and loss
    val gainArea = chartHeight * (maxGain / range).toFloat()
    val lossArea = chartHeight * (maxLoss / range).toFloat()

    val grow = remember(months) { Animatable(0f) }
    LaunchedEffect(months) { grow.animateTo(1f, tween(durationMillis = 800)) }

    val scroll = rememberScrollState()
    // Show the latest months first (the row is scrollable to the past)
    LaunchedEffect(scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }

    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(scroll), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        months.forEachIndexed { index, m ->
            val isSelected = index == selected
            val barColor = if (m.profit < 0) LossRed else SuccessGreen
            val barHeight = chartHeight * (abs(m.profit) / range).toFloat() * grow.value
            Column(
                modifier = Modifier
                    .width(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isSelected) PrimaryIndigoSoft else Color.Transparent)
                    .clickable { onSelect(index) }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (m.sold > 0) FormatUtils.formatCurrencyShort(m.profit) else "",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (m.sold > 0) barColor else TextMuted,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Box(modifier = Modifier.height(gainArea).width(20.dp), contentAlignment = Alignment.BottomCenter) {
                    if (m.profit > 0) {
                        Box(Modifier.fillMaxWidth().height(barHeight).clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)).background(barColor))
                    }
                }
                // Zero line; a month without sales shows only this
                Box(modifier = Modifier.width(30.dp).height(2.dp).background(if (m.sold > 0) barColor.copy(alpha = 0.5f) else TagBackground))
                Box(modifier = Modifier.height(lossArea).width(20.dp), contentAlignment = Alignment.TopCenter) {
                    if (m.profit < 0) {
                        Box(Modifier.fillMaxWidth().height(barHeight).clip(RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp)).background(barColor))
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    FormatUtils.formatMonthShort(m.month),
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) PrimaryIndigo else TextSecondary
                )
                // Year under January and under the first month so the timeline is readable
                Text(
                    text = if (index == 0 || m.month.month == Month.JANUARY) "${m.month.year}" else "",
                    fontSize = 9.sp,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
private fun MonthDetail(m: MonthActivity) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TagBackground)
            .padding(12.dp)
    ) {
        Text(FormatUtils.formatMonth(m.month).replaceFirstChar { it.uppercase() }, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            DetailValue("Compradas", "${m.bought}", if (m.bought > 0) FormatUtils.formatCurrency(m.spent) else "—", Modifier.weight(1f))
            DetailValue("Vendidas", "${m.sold}", if (m.sold > 0) FormatUtils.formatCurrency(m.revenue) else "—", Modifier.weight(1f))
            DetailValue(
                "Lucro",
                if (m.sold > 0) FormatUtils.formatCurrency(m.profit, true) else "—",
                if (m.sold > 0 && m.revenue - m.profit > 0) "${FormatUtils.formatPercent(m.profit / (m.revenue - m.profit) * 100, true)} retorno" else "",
                Modifier.weight(1.2f),
                valueColor = when {
                    m.sold == 0 -> TextPrimary
                    m.profit < 0 -> LossRed
                    else -> SuccessGreen
                }
            )
        }
    }
}

@Composable
private fun DetailValue(label: String, value: String, detail: String, modifier: Modifier = Modifier, valueColor: Color = TextPrimary) {
    Column(modifier = modifier) {
        Text(label, fontSize = 11.sp, color = TextMuted)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = valueColor)
        if (detail.isNotEmpty()) Text(detail, fontSize = 11.sp, color = TextSecondary)
    }
}

@Composable
private fun EmptyChart(message: String) {
    Box(
        modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(12.dp)).background(TagBackground),
        contentAlignment = Alignment.Center
    ) {
        Text(message, fontSize = 12.sp, color = TextSecondary)
    }
}
