# Walkthrough — Base de Dados Room Completa

Implementação da persistência local completa utilizando **Room (SQLite)**, gestão de utilizadores (Registo e Login), associação de dados por utilizador e fluxos reativos.

## Alterações Realizadas

### 1. Entidades Room (`pt.ubi.di.pdm.cardfolio.data`)
- **[NEW]** `UserEntity.kt`: Tabela de utilizadores (`users`).
- **[NEW]** `CardEntity.kt`: Tabela de cartas (`cards`) associada a `userId`.
- **[NEW]** `CatalogEntities.kt`: Tabelas para categorias, coleções, jogadores e clubes associadas a `userId`.

### 2. DAOs e Base de Dados (`pt.ubi.di.pdm.cardfolio.data`)
- **[NEW]** `Daos.kt`: Interfaces `UserDao`, `CardDao` e `CatalogDao` síncronas/reativas compatíveis com KSP.
- **[NEW]** `CardDatabase.kt`: Instância Room Database com pré-população automática de utilizador de demonstração, catálogo inicial e amostras de cartas na primeira criação.

### 3. Repositório e ViewModel (`pt.ubi.di.pdm.cardfolio.data`, `pt.ubi.di.pdm.cardfolio.viewmodel`)
- **[MODIFY]** `CardRepository.kt`: Adaptado para ler e escrever diretamente na base de dados Room com `Flow` reativo associado ao utilizador ativo.
- **[MODIFY]** `CardViewModel.kt`: Estendido com `AndroidViewModel` e métodos de autenticação (*Login* e *Registo*).
- **[MODIFY]** `LoginScreen.kt` & `RegisterScreen.kt`: Ligados aos métodos de autenticação do ViewModel com tratamento de erros.

## Resultados da Validação
- **Build**: Compilado com sucesso (`Build finished successfully.`).
