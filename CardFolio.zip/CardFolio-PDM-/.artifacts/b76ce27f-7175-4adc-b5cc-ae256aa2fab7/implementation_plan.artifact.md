# Plano de Implementação — Base de Dados Room Completa (Cardfolio)

Migração da persistência atual para uma base de dados local robusta e persistente usando **Room (SQLite)** em Kotlin, incluindo **gestão de utilizadores (Registo e Login)**, associação de **cartas/cromos por utilizador**, catálogo e cálculo de KPIs persistidos, mantendo a reatividade total com `Flow`.

## User Review Required

> [!IMPORTANT]
> - **Gestão de Utilizadores**: Tabela `UserEntity` para suportar Registo, Login e autenticação local.
> - **Associação por Utilizador**: Cartas (`CardEntity`) e itens de catálogo associados ao `userId` do utilizador ativo.
> - **Room Database & DAOs**: Configuração da base de dados Room com migrações, type converters e pré-população inicial de dados de demonstração.

## Proposed Changes

### 1. Entidades Room (`pt.ubi.di.pdm.cardfolio.data`)
- **[NEW]** `UserEntity.kt`: Tabela de utilizadores (id, name, email, password, photoUri).
- **[NEW]** `CardEntity.kt`: Tabela de cartas associada a `userId`.
- **[NEW]** `CatalogEntities.kt`: Tabelas para `CategoryEntity`, `CollectionEntity`, `PlayerEntity` e `ClubEntity` associadas a `userId`.

### 2. DAOs e Base de Dados (`pt.ubi.di.pdm.cardfolio.data`)
- **[NEW]** `UserDao.kt`, `CardDao.kt`, `CatalogDao.kt`: Interfaces DAO para operações de autenticação e gestão reativa (`Flow`).
- **[NEW]** `CardDatabase.kt`: Instância Room Database com TypeConverters e seeding de dados iniciais.

### 3. Repositório e ViewModel (`pt.ubi.di.pdm.cardfolio.data`, `pt.ubi.di.pdm.cardfolio.viewmodel`)
- **[MODIFY]** `CardRepository.kt`: Integrar DAOs do Room, gerindo o estado do utilizador autenticado (`userId`) e fluxos reativos.
- **[MODIFY]** `CardViewModel.kt`: Ligar ecrãs de Login, Registo e Perfis ao repositório Room persistente.

## Verification Plan

### Automated Tests
- Compilação do projeto com Gradle (`app:assembleDebug`).

### Manual Verification
- Registar um novo utilizador ou fazer login, adicionar cartas e coleções, fechar a aplicação e reabrir para confirmar persistência completa por utilizador.
