# Tarefas de Execução — Base de Dados Room Completa

- `[x]` Task 1: Criar entidades Room, DAOs e a classe `CardDatabase` com TypeConverters e pré-população inicial
- `[x]` Task 2: Adaptar o `CardRepository` para utilizar a base de dados Room com fluxos reativos por utilizador autenticado
- `[x]` Task 3: Atualizar `CardViewModel` e ecrãs de Login, Registo e Catálogo para persistência completa
- `[x]` Task 4: Verificar compilação e teste do fluxo end-to-end (Build finished successfully)
